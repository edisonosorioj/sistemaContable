-- MySQL dump 10.16  Distrib 10.1.41-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: brokersf_co
-- ------------------------------------------------------
-- Server version	10.1.41-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_actividad_economica`
--

DROP TABLE IF EXISTS `tbl_actividad_economica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_actividad_economica` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_actividad_economica`
--

LOCK TABLES `tbl_actividad_economica` WRITE;
/*!40000 ALTER TABLE `tbl_actividad_economica` DISABLE KEYS */;
INSERT INTO `tbl_actividad_economica` (`codigo`, `nombre`) VALUES (1,'Estudiante'),(2,'Asalariado'),(3,'Socio'),(4,'Pensionado'),(5,'Jubilado'),(6,'Rentista'),(7,'Otro');
/*!40000 ALTER TABLE `tbl_actividad_economica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bien_adquirido`
--

DROP TABLE IF EXISTS `tbl_bien_adquirido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bien_adquirido` (
  `codigo` int(11) NOT NULL,
  `direccion` varchar(255) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ciudad` int(11) DEFAULT NULL,
  `matricula` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `usuario` int(15) NOT NULL,
  `marca` varchar(45) COLLATE latin1_spanish_ci DEFAULT NULL,
  `modelo` int(11) DEFAULT NULL,
  `placa` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `tipo` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `tipo_idx` (`tipo`) USING BTREE,
  KEY `usuario_idx` (`usuario`) USING BTREE,
  KEY `ciudad_idx` (`ciudad`) USING BTREE,
  CONSTRAINT `tbl_bien_adquirido_ibfk_1` FOREIGN KEY (`ciudad`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_bien_adquirido_ibfk_2` FOREIGN KEY (`tipo`) REFERENCES `tbl_tipo_bien` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_bien_adquirido_ibfk_3` FOREIGN KEY (`usuario`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bien_adquirido`
--

LOCK TABLES `tbl_bien_adquirido` WRITE;
/*!40000 ALTER TABLE `tbl_bien_adquirido` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_bien_adquirido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_ciudad`
--

DROP TABLE IF EXISTS `tbl_ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_ciudad` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `provincia` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `departamento_idx` (`provincia`),
  CONSTRAINT `departamento` FOREIGN KEY (`provincia`) REFERENCES `tbl_provincia` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_ciudad`
--

LOCK TABLES `tbl_ciudad` WRITE;
/*!40000 ALTER TABLE `tbl_ciudad` DISABLE KEYS */;
INSERT INTO `tbl_ciudad` (`codigo`, `nombre`, `provincia`) VALUES (1,'El Carmen de Viboral ',1),(2,'Abejorral',1),(3,'Abriaqui',1),(4,'Alejandria',1),(5,'Amag&aacute;',1),(6,'Amalfi',1),(7,'Andes',1),(8,'Rionegro ',1),(9,'Angel&oacute;polis',1),(10,'Angostura',1),(11,'Anor&iacute;',1),(12,'Anz&aacute;',1),(13,'Apartad&oacute;',1),(14,'Arboletes',1),(15,'Armenia',1),(16,'Barbosa',1),(17,'Argelia',1),(18,'Bello',1),(19,'Belmira',1),(20,'Betania',1),(21,'Betulia',1),(22,'Brice&ntilde;o',1),(23,'Buritic&aacute;',1),(24,'C&aacute;ceres',1),(25,'Caicedo',1),(26,'Caldas',1),(27,'Campamento',1),(28,'Ca&ntilde;asgordas',1),(29,'Caracol&iacute;',1),(30,'Caramanta',1),(31,'Carepa',1),(32,'Carolina del Pr&iacute;ncipe',1),(33,'Caucasia',1),(34,'Chigorod&oacute;',1),(35,'Cisneros',1),(36,'Ciudad Bol&iacute;var',1),(37,'Cocorn&aacute;',1),(38,'Concepci&oacute;n',1),(39,'Concordia',1),(40,'Copacabana',1),(41,'Dabeiba',1),(42,'Donmat&iacute;as',1),(43,'Eb&eacute;jico',1),(44,'El Bagre',1),(45,'El pe&ntilde;ol',1),(46,'El Retiro',1),(47,'El Santuario',1),(48,'Entrerr&iacute;os',1),(49,'Envigado',1),(50,'Fredonia',1),(51,'Frontino',1),(52,'Giraldo',1),(53,'Girardota',1),(54,'G&oacute;mez Plata',1),(55,'Granada',1),(56,'Guadalupe',1),(57,'Guarne',1),(58,'Guatap&eacute;',1),(59,'Heliconia',1),(60,'Hispania',1),(61,'Itag&uuml;&iacute;',1),(62,'Ituango',1),(63,'Jard&iacute;n',1),(64,'Jeric&oacute;',1),(65,'La Ceja',1),(66,'La Estrella',1),(67,'La Pintada',1),(68,'La Uni&oacute;n',1),(69,'Liborina',1),(70,'Maceo',1),(71,'Marinilla',1),(72,'Medell&iacute;n',1),(73,'Montebello',1),(74,'Murind&oacute;',1),(75,'Mutat&aacute;',1),(76,'Nari&ntilde;o',1),(77,'Nech&iacute;',1),(78,'Necocl&iacute;',1),(79,'Olaya',1),(80,'Peque',1),(81,'Pueblorrico',1),(82,'Puerto Berr&iacute;o',1),(83,'Puerto Nare',1),(84,'Puerto Triunfo',1),(85,'Remedios',1),(86,'Sabanalarga',1),(87,'Sabaneta',1),(88,'Salgar',1),(89,'San Andr&eacute;s de Cuerquia',1),(90,'San Carlos',1),(91,'San Francisco',1),(92,'San Jer&oacute;nimo',1),(93,'San Jos&eacute; de la Monta&ntilde;a',1),(94,'San Juan de Urab&aacute;',1),(95,'San Luis',1),(96,'San Pedro de los Milagros',1),(97,'San Pedro de Urab&aacute;',1),(98,'San Rafael',1),(99,'San Roque',1),(100,'San Vicente',1),(101,'Santa B&aacute;rbara',1),(102,'Santa Rosa de Osos',1),(103,'Santa Fe de Antioquia',1),(104,'Santo Domingo',1),(105,'Segovia',1),(106,'Sons&oacute;n',1),(107,'Sopetr&aacute;n',1),(108,'T&aacute;mesis',1),(109,'Taraz&aacute;',1),(110,'Tarso',1),(111,'Titirib&iacute;',1),(112,'Toledo',1),(113,'Turbo',1),(114,'Uramita',1),(115,'Urrao',1),(116,'Valdivia',1),(117,'Valpara&iacute;so',1),(118,'Vegach&iacute;',1),(119,'Venecia',1),(120,'Vig&iacute;a del Fuerte',1),(121,'Yal&iacute;',1),(122,'Yarumal',1),(123,'Yolomb&oacute;',1),(124,'Yond&oacute;',1),(125,'Zaragoza',1);
/*!40000 ALTER TABLE `tbl_ciudad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cocina`
--

DROP TABLE IF EXISTS `tbl_cocina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cocina` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cocina`
--

LOCK TABLES `tbl_cocina` WRITE;
/*!40000 ALTER TABLE `tbl_cocina` DISABLE KEYS */;
INSERT INTO `tbl_cocina` (`codigo`, `nombre`) VALUES (1,'Sencilla'),(2,'Semi-Integral '),(3,'Integral'),(4,'Mixta');
/*!40000 ALTER TABLE `tbl_cocina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_codeudores`
--

DROP TABLE IF EXISTS `tbl_codeudores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_codeudores` (
  `documento` int(15) NOT NULL,
  `usuario_relacion` int(11) NOT NULL,
  `nombres` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `tel_personal` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `salario` int(11) NOT NULL,
  `egreso` int(11) DEFAULT NULL,
  `tipo_documento` int(11) NOT NULL,
  `lugar_expedicion` int(11) NOT NULL,
  `fecha_expedicion` date NOT NULL,
  `situacion_laboral` int(11) NOT NULL,
  `empresa_trabajo` int(11) NOT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `actividad_economica` int(11) NOT NULL,
  `descripcion_actividad` varchar(250) COLLATE latin1_spanish_ci DEFAULT NULL,
  `profesion` int(11) NOT NULL,
  `url_documento` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`documento`),
  KEY `usuario_rel_codeudor_idx` (`usuario_relacion`),
  KEY `prefesion_codeudor_idx` (`profesion`),
  KEY `lugar_expedicion_idx` (`lugar_expedicion`),
  KEY `tipo_documento_codeudor_idx` (`tipo_documento`),
  KEY `situacion_laboral_codeudor_idx` (`situacion_laboral`),
  KEY `empresa_trabjo_codeudor_idx` (`empresa_trabajo`),
  KEY `actividad_economica` (`actividad_economica`),
  CONSTRAINT `empresa_trabjo_codeudor` FOREIGN KEY (`empresa_trabajo`) REFERENCES `tbl_empresa_trabajo` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lugar_expedicion` FOREIGN KEY (`lugar_expedicion`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `prefesion_codeudor` FOREIGN KEY (`profesion`) REFERENCES `tbl_profesion` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `situacion_laboral_codeudor` FOREIGN KEY (`situacion_laboral`) REFERENCES `tbl_situacion_laboral` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_codeudores_ibfk_1` FOREIGN KEY (`actividad_economica`) REFERENCES `tbl_actividad_economica` (`codigo`),
  CONSTRAINT `tipo_documento_codeudor` FOREIGN KEY (`tipo_documento`) REFERENCES `tbl_tipo_documento` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuario_rel_codeudor` FOREIGN KEY (`usuario_relacion`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_codeudores`
--

LOCK TABLES `tbl_codeudores` WRITE;
/*!40000 ALTER TABLE `tbl_codeudores` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_codeudores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_comodidad_general_propiedad`
--

DROP TABLE IF EXISTS `tbl_comodidad_general_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_comodidad_general_propiedad` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `icon` varchar(100) DEFAULT NULL COMMENT 'Iconos de Comodidades',
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_comodidad_general_propiedad`
--

LOCK TABLES `tbl_comodidad_general_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_comodidad_general_propiedad` DISABLE KEYS */;
INSERT INTO `tbl_comodidad_general_propiedad` (`codigo`, `nombre`, `icon`) VALUES (1,'Balcón','panorama_wide_angle'),(2,'Patio o Terraza','looks'),(3,'Biblioteca/star','star'),(4,'Closet/Cuarto de linos','view_carousel'),(5,'Alarma','access_alarm'),(6,'Aire acondicionado','waves'),(7,'Dispositivo de domotica','border_outer'),(8,'Red de Gas ','bubble_chart'),(9,'Zona de Ropas ','local_laundry_service'),(10,'Calentador de agua ','hot_tub'),(11,'Ascensor','panorama_vertical'),(13,'Citofono','ring_volume'),(14,'Shut the basura','delete'),(15,'Parqueadero para visitantes','airport_shuttle'),(16,'Salon Social','group'),(17,'Cancha Polideportiva','transfer_within_a_station'),(18,'Zona BBQ','whatshot'),(19,'Juegos Infantiles','insert_emoticon'),(20,'Zonas Verdes','nature_people'),(21,'Zona Pet friendly','nature'),(22,'Pista de Trote o Senderos','directions_run'),(23,'Jacuzzi','hot_tub'),(24,'Turco','spa'),(25,'Piscina Climatizada','pool'),(26,'Circuito Cerrado de TV','tv'),(27,'Porteria','how_to_reg'),(28,'Horario Porteria','access_time');
/*!40000 ALTER TABLE `tbl_comodidad_general_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_comodidades_copropiedad`
--

DROP TABLE IF EXISTS `tbl_comodidades_copropiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_comodidades_copropiedad` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_comodidades_copropiedad`
--

LOCK TABLES `tbl_comodidades_copropiedad` WRITE;
/*!40000 ALTER TABLE `tbl_comodidades_copropiedad` DISABLE KEYS */;
INSERT INTO `tbl_comodidades_copropiedad` (`codigo`, `nombre`) VALUES (1,'Ascensor '),(2,'Citófono'),(3,'Shut de Basura '),(4,'Parqueadero Visitantes '),(5,'Salón social '),(6,'Cancha polideportiva '),(7,'Zona BBQ'),(8,'Juegos infantiles '),(9,'Zonas verdes '),(10,'Pista de trote o senderos'),(11,'Jacuzzi'),(12,'Turco'),(13,'Gimnasio '),(14,'Piscina climatizada '),(15,'Circuito cerrado de TV'),(16,'Portería ');
/*!40000 ALTER TABLE `tbl_comodidades_copropiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_compra_paquete`
--

DROP TABLE IF EXISTS `tbl_compra_paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_compra_paquete` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `paquete` int(11) NOT NULL,
  `fecha_inicial` date NOT NULL,
  `fecha_final` date NOT NULL,
  `valor` int(11) NOT NULL,
  `estado_compra_paquete` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `paquete_idx` (`paquete`),
  KEY `estadio_idx` (`estado_compra_paquete`),
  CONSTRAINT `estadio` FOREIGN KEY (`estado_compra_paquete`) REFERENCES `tbl_estado_compra_paquete` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paquete` FOREIGN KEY (`paquete`) REFERENCES `tbl_paquete` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_compra_paquete`
--

LOCK TABLES `tbl_compra_paquete` WRITE;
/*!40000 ALTER TABLE `tbl_compra_paquete` DISABLE KEYS */;
INSERT INTO `tbl_compra_paquete` (`codigo`, `fecha`, `paquete`, `fecha_inicial`, `fecha_final`, `valor`, `estado_compra_paquete`) VALUES (2,'2018-05-17',2,'2018-05-17','2018-07-17',200,2),(3,'2018-05-17',3,'2018-03-14','2018-04-14',300,3),(4,'2018-05-17',4,'2018-05-01','2018-09-01',500000,1);
/*!40000 ALTER TABLE `tbl_compra_paquete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_constructora`
--

DROP TABLE IF EXISTS `tbl_constructora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_constructora` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_constructora`
--

LOCK TABLES `tbl_constructora` WRITE;
/*!40000 ALTER TABLE `tbl_constructora` DISABLE KEYS */;
INSERT INTO `tbl_constructora` (`codigo`, `nombre`) VALUES (1,'Constructora a'),(2,'Constructora b');
/*!40000 ALTER TABLE `tbl_constructora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_conversaciones`
--

DROP TABLE IF EXISTS `tbl_conversaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_conversaciones` (
  `codigo` int(11) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `emisor` int(11) NOT NULL,
  `receptor` int(11) NOT NULL,
  `mensaje` varchar(2000) NOT NULL,
  `propiedad` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `receptor_idx` (`receptor`),
  KEY `emisor_idx` (`emisor`),
  KEY `propiedad_idx` (`propiedad`),
  CONSTRAINT `emisor_c` FOREIGN KEY (`emisor`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `propiedad_c` FOREIGN KEY (`propiedad`) REFERENCES `tbl_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `receptor_c` FOREIGN KEY (`receptor`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_conversaciones`
--

LOCK TABLES `tbl_conversaciones` WRITE;
/*!40000 ALTER TABLE `tbl_conversaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_conversaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_conyuge`
--

DROP TABLE IF EXISTS `tbl_conyuge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_conyuge` (
  `documento` int(15) NOT NULL,
  `nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `tel_personal` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `situacion_laboral` int(11) NOT NULL,
  `lugar_expedicion` int(11) NOT NULL,
  `fecha_expedicion` date NOT NULL,
  `empresa_trabajo` int(11) DEFAULT NULL,
  `sueldo` int(11) DEFAULT NULL,
  `profesion` int(11) DEFAULT NULL,
  `tipo_documento` int(11) NOT NULL,
  `usuario_relacion` int(15) NOT NULL,
  PRIMARY KEY (`documento`),
  KEY `situacion_laboral` (`situacion_laboral`),
  KEY `profesion` (`profesion`),
  KEY `tipo_documento` (`tipo_documento`),
  KEY `usuario_relacion` (`usuario_relacion`),
  KEY `lugar_expedicion` (`lugar_expedicion`),
  KEY `empresa_trabajo_idx` (`empresa_trabajo`) USING BTREE,
  CONSTRAINT `tbl_conyuge_ibfk_1` FOREIGN KEY (`lugar_expedicion`) REFERENCES `tbl_ciudad` (`codigo`),
  CONSTRAINT `tbl_conyuge_ibfk_2` FOREIGN KEY (`profesion`) REFERENCES `tbl_profesion` (`codigo`),
  CONSTRAINT `tbl_conyuge_ibfk_3` FOREIGN KEY (`tipo_documento`) REFERENCES `tbl_tipo_documento` (`codigo`),
  CONSTRAINT `tbl_conyuge_ibfk_4` FOREIGN KEY (`usuario_relacion`) REFERENCES `tbl_usuario` (`documento`),
  CONSTRAINT `tbl_conyuge_ibfk_5` FOREIGN KEY (`situacion_laboral`) REFERENCES `tbl_situacion_laboral` (`codigo`),
  CONSTRAINT `tbl_conyuge_ibfk_6` FOREIGN KEY (`empresa_trabajo`) REFERENCES `tbl_empresa_trabajo` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_conyuge`
--

LOCK TABLES `tbl_conyuge` WRITE;
/*!40000 ALTER TABLE `tbl_conyuge` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_conyuge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_copropiedad`
--

DROP TABLE IF EXISTS `tbl_copropiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_copropiedad` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_copropiedad`
--

LOCK TABLES `tbl_copropiedad` WRITE;
/*!40000 ALTER TABLE `tbl_copropiedad` DISABLE KEYS */;
INSERT INTO `tbl_copropiedad` (`codigo`, `nombre`) VALUES (1,'Copropiedad 1');
/*!40000 ALTER TABLE `tbl_copropiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_copropiedad_comodidades_copropiedad`
--

DROP TABLE IF EXISTS `tbl_copropiedad_comodidades_copropiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_copropiedad_comodidades_copropiedad` (
  `codigo_copropiedad` int(11) NOT NULL,
  `codigo_comodidad_copropiedad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_copropiedad`,`codigo_comodidad_copropiedad`),
  KEY `coporpiedad_idx` (`codigo_copropiedad`),
  KEY `comodidad_copropiedad_a` (`codigo_comodidad_copropiedad`),
  CONSTRAINT `comodidad_copropiedad_a` FOREIGN KEY (`codigo_comodidad_copropiedad`) REFERENCES `tbl_comodidades_copropiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `copropiedad_a` FOREIGN KEY (`codigo_copropiedad`) REFERENCES `tbl_copropiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_copropiedad_comodidades_copropiedad`
--

LOCK TABLES `tbl_copropiedad_comodidades_copropiedad` WRITE;
/*!40000 ALTER TABLE `tbl_copropiedad_comodidades_copropiedad` DISABLE KEYS */;
INSERT INTO `tbl_copropiedad_comodidades_copropiedad` (`codigo_copropiedad`, `codigo_comodidad_copropiedad`) VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16);
/*!40000 ALTER TABLE `tbl_copropiedad_comodidades_copropiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_empresa_trabajo`
--

DROP TABLE IF EXISTS `tbl_empresa_trabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_empresa_trabajo` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE latin1_spanish_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha_ingreso` date NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `salario` int(11) NOT NULL,
  `egreso` int(11) NOT NULL,
  `otro_ingreso` int(11) NOT NULL,
  `ciudad` int(11) DEFAULT NULL,
  `actividad_economica` int(11) DEFAULT NULL,
  `registro_mercantil` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `ciudad_empresa_trabajo_idx` (`ciudad`),
  KEY `actividad_economica_idx` (`actividad_economica`) USING BTREE,
  KEY `registro_mercantil_idx` (`registro_mercantil`) USING BTREE,
  CONSTRAINT `ciudad_empresa_trabajo` FOREIGN KEY (`ciudad`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_empresa_trabajo_ibfk_1` FOREIGN KEY (`actividad_economica`) REFERENCES `tbl_actividad_economica` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_empresa_trabajo_ibfk_2` FOREIGN KEY (`registro_mercantil`) REFERENCES `tbl_registro_mercantil_independiente` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_empresa_trabajo`
--

LOCK TABLES `tbl_empresa_trabajo` WRITE;
/*!40000 ALTER TABLE `tbl_empresa_trabajo` DISABLE KEYS */;
INSERT INTO `tbl_empresa_trabajo` (`codigo`, `nombre`, `descripcion`, `direccion`, `fecha_ingreso`, `telefono`, `salario`, `egreso`, `otro_ingreso`, `ciudad`, `actividad_economica`, `registro_mercantil`) VALUES (1,'Brokers','Brokers soluciones','Cra 54 85-90','0000-00-00','3004003243',0,0,0,8,1,NULL),(2,'',NULL,'','0000-00-00','',0,0,0,18,2,NULL),(3,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','12345677',0,0,0,13,2,NULL),(4,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','1234555',0,0,0,11,2,NULL),(5,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','1234555',0,0,0,11,2,NULL),(6,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','12345678',0,0,0,12,2,NULL),(7,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','12345678',0,0,0,12,2,NULL),(8,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','12345678',0,0,0,12,2,NULL),(9,'El mercado verde',NULL,'La plaza de mercados','0000-00-00','12345678',0,0,0,12,2,NULL),(10,'El buke',NULL,'1234567','0000-00-00','3124258797',0,0,0,25,2,NULL),(11,'El buke',NULL,'1234567','0000-00-00','3124258797',0,0,0,25,2,NULL),(12,'El bukeEl bukeEl buke',NULL,'00sdfgvdxfg','0000-00-00','3124258797',0,0,0,10,2,NULL),(13,'El bukeEl bukeEl buke',NULL,'00sdfgvdxfg','0000-00-00','3124258797',0,0,0,10,2,NULL),(14,'El bukeEl bukeEl buke',NULL,'00sdfgvdxfg','0000-00-00','3124258797',0,0,0,10,2,NULL),(15,NULL,'El carro ',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(16,'El carro ',NULL,'00sdfgvdxfg','0000-00-00','3113735911',0,0,0,10,2,NULL),(17,'El carro ',NULL,'2000','0000-00-00','3113735911',0,0,0,10,2,NULL),(18,'El carro ',NULL,'2000','0000-00-00','3113735911',0,0,0,10,2,NULL),(19,'El carro ',NULL,'2000','0000-00-00','3113735911',0,0,0,10,2,NULL),(20,'El carro ',NULL,'2000','0000-00-00','3113735911',0,0,0,10,2,NULL),(21,'El carro ',NULL,'2000','0000-00-00','3113735911',0,0,0,10,2,NULL),(22,'El carro ',NULL,'2000','0000-00-00','3113735911',0,0,0,10,2,NULL),(23,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00','1234567897',0,0,0,10,2,NULL),(24,NULL,'Me dan plata mis papa',NULL,'0000-00-00','3113735915',0,0,0,10,2,NULL),(25,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(26,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(27,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(28,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(29,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(30,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(31,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(32,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(33,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(34,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(35,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(36,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(37,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(38,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(39,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(40,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(41,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(42,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(43,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(44,NULL,'Me dan plata mis papaMe dan plata mis papa',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL),(45,'Me jode',NULL,'El barro de las tolerancias ','0000-00-00',NULL,0,0,0,NULL,2,NULL),(46,NULL,'No me dan',NULL,'0000-00-00',NULL,0,0,0,NULL,2,NULL);
/*!40000 ALTER TABLE `tbl_empresa_trabajo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estado_civil`
--

DROP TABLE IF EXISTS `tbl_estado_civil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estado_civil` (
  `codigo` int(1) NOT NULL,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estado_civil`
--

LOCK TABLES `tbl_estado_civil` WRITE;
/*!40000 ALTER TABLE `tbl_estado_civil` DISABLE KEYS */;
INSERT INTO `tbl_estado_civil` (`codigo`, `nombre`) VALUES (1,'Casado(a)'),(2,'Divorciado(a)'),(3,'Viudo(a)'),(4,'Soltero(a)'),(5,'Separado(a)'),(6,'Unión libre(a)');
/*!40000 ALTER TABLE `tbl_estado_civil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estado_compra_paquete`
--

DROP TABLE IF EXISTS `tbl_estado_compra_paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estado_compra_paquete` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estado_compra_paquete`
--

LOCK TABLES `tbl_estado_compra_paquete` WRITE;
/*!40000 ALTER TABLE `tbl_estado_compra_paquete` DISABLE KEYS */;
INSERT INTO `tbl_estado_compra_paquete` (`codigo`, `nombre`) VALUES (1,'Aprobado'),(2,'En Proceso'),(3,'Anulado');
/*!40000 ALTER TABLE `tbl_estado_compra_paquete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estado_operacion`
--

DROP TABLE IF EXISTS `tbl_estado_operacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estado_operacion` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estado_operacion`
--

LOCK TABLES `tbl_estado_operacion` WRITE;
/*!40000 ALTER TABLE `tbl_estado_operacion` DISABLE KEYS */;
INSERT INTO `tbl_estado_operacion` (`codigo`, `nombre`) VALUES (1,'Activo'),(2,'Inactivo');
/*!40000 ALTER TABLE `tbl_estado_operacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estado_pago_arriendo`
--

DROP TABLE IF EXISTS `tbl_estado_pago_arriendo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estado_pago_arriendo` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estado_pago_arriendo`
--

LOCK TABLES `tbl_estado_pago_arriendo` WRITE;
/*!40000 ALTER TABLE `tbl_estado_pago_arriendo` DISABLE KEYS */;
INSERT INTO `tbl_estado_pago_arriendo` (`codigo`, `nombre`) VALUES (1,'Pagado'),(2,'Debe  ');
/*!40000 ALTER TABLE `tbl_estado_pago_arriendo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estado_pago_paquete`
--

DROP TABLE IF EXISTS `tbl_estado_pago_paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estado_pago_paquete` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estado_pago_paquete`
--

LOCK TABLES `tbl_estado_pago_paquete` WRITE;
/*!40000 ALTER TABLE `tbl_estado_pago_paquete` DISABLE KEYS */;
INSERT INTO `tbl_estado_pago_paquete` (`codigo`, `nombre`) VALUES (1,'Activo'),(2,'Inactivo');
/*!40000 ALTER TABLE `tbl_estado_pago_paquete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_estado_propiedad`
--

DROP TABLE IF EXISTS `tbl_estado_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estado_propiedad` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(15) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estado_propiedad`
--

LOCK TABLES `tbl_estado_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_estado_propiedad` DISABLE KEYS */;
INSERT INTO `tbl_estado_propiedad` (`codigo`, `nombre`) VALUES (1,'Activo'),(2,'Inactivo');
/*!40000 ALTER TABLE `tbl_estado_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_genero`
--

DROP TABLE IF EXISTS `tbl_genero`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_genero` (
  `codigo` int(1) NOT NULL,
  `nombre` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_genero`
--

LOCK TABLES `tbl_genero` WRITE;
/*!40000 ALTER TABLE `tbl_genero` DISABLE KEYS */;
INSERT INTO `tbl_genero` (`codigo`, `nombre`) VALUES (1,'Maculino'),(2,'Femenino'),(3,'Otro');
/*!40000 ALTER TABLE `tbl_genero` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_historial`
--

DROP TABLE IF EXISTS `tbl_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_historial` (
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `puntuacion` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_historial`
--

LOCK TABLES `tbl_historial` WRITE;
/*!40000 ALTER TABLE `tbl_historial` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_imagen`
--

DROP TABLE IF EXISTS `tbl_imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_imagen` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_imagen`
--

LOCK TABLES `tbl_imagen` WRITE;
/*!40000 ALTER TABLE `tbl_imagen` DISABLE KEYS */;
INSERT INTO `tbl_imagen` (`codigo`, `nombre`) VALUES (46,'F769ah0sMnB.jpg'),(47,'zc4bY0kP2IV.jpg'),(48,'ExKEtoQOhdj.jpg'),(49,'8AoLK02EfV8.jpg'),(50,'3xjuzOMcoeP.jpg'),(51,'1WmRfm5I05f.jpg'),(52,'sjf40aU5ics.jpg'),(53,'tYhHgNn9mBq.jpg'),(54,'tp39FHmJf2p.jpg'),(55,'r31HozsG9pN.jpg'),(56,'m_OLuifYbzw.jpg'),(57,'Pdhsd9Y8h5Y.jpg'),(58,'LAjwTQAdqLU.jpg'),(59,'kdm4sLoteiJ.jpg'),(60,'aYM_ZRxkuWC.jpg'),(61,'os65pO43odI.jpg'),(62,'HE_oaRRNtoQ.jpg'),(63,'VaP6kVeZqIC.jpg'),(64,'Foto01.jpeg'),(65,'Foto02.jpg'),(66,'Foto03.jpg'),(67,'Foto04.jpg'),(68,'Foto05.jpg'),(69,'Foto06.jpg'),(70,'Foto07.jpg'),(71,'Foto08.jpeg'),(72,'Foto10.jpeg'),(73,'Foto11.jpeg'),(74,'Foto12.jpeg'),(75,'Foto13.jpeg'),(76,'Foto14.jpeg'),(77,'Foto15.jpeg'),(78,'Foto16.jpeg'),(79,'Foto17.jpeg'),(80,'Foto18.jpeg'),(81,'Foto19.jpeg'),(82,'Foto20.jpeg'),(83,'Foto21.jpeg'),(84,'Foto22.jpeg'),(85,'Foto23.jpeg'),(86,'Foto24.jpeg'),(87,'Foto25.jpeg'),(88,'Foto26.jpeg'),(89,'Foto27.jpeg'),(90,'Foto28.jpeg'),(91,'Foto29.jpeg'),(92,'Foto30.jpeg'),(93,'Foto31.jpg'),(94,'Foto32.jpg'),(95,'Foto33.jpg'),(96,'Foto34.jpg'),(97,'Foto35.jpg'),(98,'Foto36.jpg');
/*!40000 ALTER TABLE `tbl_imagen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_imagen_propiedad`
--

DROP TABLE IF EXISTS `tbl_imagen_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_imagen_propiedad` (
  `codigo_propiedad` int(11) NOT NULL,
  `codigo_imagen` int(11) NOT NULL,
  PRIMARY KEY (`codigo_propiedad`,`codigo_imagen`),
  KEY `imagen_idx` (`codigo_imagen`),
  CONSTRAINT `imagen` FOREIGN KEY (`codigo_imagen`) REFERENCES `tbl_imagen` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `propiedad` FOREIGN KEY (`codigo_propiedad`) REFERENCES `tbl_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_imagen_propiedad`
--

LOCK TABLES `tbl_imagen_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_imagen_propiedad` DISABLE KEYS */;
INSERT INTO `tbl_imagen_propiedad` (`codigo_propiedad`, `codigo_imagen`) VALUES (142,46),(142,47),(142,48),(142,49),(142,50),(142,51),(142,52),(142,53),(142,54),(144,55),(144,56),(144,57),(144,58),(144,59),(144,60),(145,61),(145,62),(145,63),(180,64),(180,65),(180,66),(180,67),(180,68),(180,69),(180,70),(180,71),(180,72),(180,73),(180,74),(180,75),(180,76),(180,77),(180,78),(180,79),(180,80),(180,81),(180,82),(180,83),(180,84),(180,85),(180,86),(180,87),(180,88),(180,89),(180,90),(180,91),(180,92),(180,93),(180,94),(180,95),(180,96),(180,97),(180,98);
/*!40000 ALTER TABLE `tbl_imagen_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_metodo_pago`
--

DROP TABLE IF EXISTS `tbl_metodo_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_metodo_pago` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(10) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_metodo_pago`
--

LOCK TABLES `tbl_metodo_pago` WRITE;
/*!40000 ALTER TABLE `tbl_metodo_pago` DISABLE KEYS */;
INSERT INTO `tbl_metodo_pago` (`codigo`, `nombre`) VALUES (1,'Consignar');
/*!40000 ALTER TABLE `tbl_metodo_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_moneda`
--

DROP TABLE IF EXISTS `tbl_moneda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_moneda` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_moneda`
--

LOCK TABLES `tbl_moneda` WRITE;
/*!40000 ALTER TABLE `tbl_moneda` DISABLE KEYS */;
INSERT INTO `tbl_moneda` (`codigo`, `nombre`) VALUES (1,'Euro'),(2,'Peso Colombiano'),(3,'Dólar Estadounidense'),(4,'Yen Japonés'),(5,'Libra Esterlina'),(6,'Dólar Australiano'),(7,'Franco Suizo'),(8,'Dólar canadiense'),(9,'Peso Mexicano'),(10,'Yuan Chino');
/*!40000 ALTER TABLE `tbl_moneda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_operacion_internacional`
--

DROP TABLE IF EXISTS `tbl_operacion_internacional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_operacion_internacional` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_operacion` int(11) NOT NULL,
  `tipo_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `moneda` int(11) NOT NULL,
  `usuario` int(11) NOT NULL,
  `pais` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `tipo_operacion_idx` (`tipo_operacion`) USING BTREE,
  KEY `tipo_producto_idx` (`tipo_producto`) USING BTREE,
  KEY `usuario_idx` (`usuario`) USING BTREE,
  KEY `moneda_idx` (`moneda`) USING BTREE,
  KEY `pais_idx` (`pais`) USING BTREE,
  CONSTRAINT `tbl_operacion_internacional_ibfk_1` FOREIGN KEY (`moneda`) REFERENCES `tbl_moneda` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_operacion_internacional_ibfk_2` FOREIGN KEY (`pais`) REFERENCES `tbl_pais` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_operacion_internacional_ibfk_3` FOREIGN KEY (`tipo_operacion`) REFERENCES `tbl_tipo_operacion_internacional` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_operacion_internacional_ibfk_4` FOREIGN KEY (`tipo_producto`) REFERENCES `tbl_tipo_producto` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_operacion_internacional_ibfk_5` FOREIGN KEY (`usuario`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_operacion_internacional`
--

LOCK TABLES `tbl_operacion_internacional` WRITE;
/*!40000 ALTER TABLE `tbl_operacion_internacional` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_operacion_internacional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_operacion_propiedad`
--

DROP TABLE IF EXISTS `tbl_operacion_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_operacion_propiedad` (
  `codigo` int(11) NOT NULL,
  `estado_operacion` int(11) NOT NULL,
  `codigo_propiedad` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tipo_operacion` int(11) NOT NULL,
  `archivo_documento_arriendo` varchar(2100) DEFAULT NULL,
  `archivo_documento_contrato` varchar(2100) DEFAULT NULL,
  `archivo_documento_pazysalvo` varchar(2100) DEFAULT NULL,
  `cliente` int(11) NOT NULL,
  `fecha_inicial_contrato` date DEFAULT NULL,
  `fecha_final_contrato` date DEFAULT NULL,
  `fecha_ultimo_pago` date DEFAULT NULL,
  `fecha_proximo_pago` date DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `tipo_operacion_idx` (`tipo_operacion`),
  KEY `propiedad_idx` (`codigo_propiedad`),
  KEY `cliente_idx` (`cliente`),
  KEY `estado_idx` (`estado_operacion`),
  CONSTRAINT `cliente_b` FOREIGN KEY (`cliente`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `estado_b` FOREIGN KEY (`estado_operacion`) REFERENCES `tbl_estado_operacion` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `propiedad_b` FOREIGN KEY (`codigo_propiedad`) REFERENCES `tbl_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_operacion_propiedad_ibfk_1` FOREIGN KEY (`codigo_propiedad`) REFERENCES `tbl_propiedad` (`codigo`),
  CONSTRAINT `tipo_operacion_b` FOREIGN KEY (`tipo_operacion`) REFERENCES `tbl_tipo_operacion` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_operacion_propiedad`
--

LOCK TABLES `tbl_operacion_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_operacion_propiedad` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_operacion_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pago_arriendo`
--

DROP TABLE IF EXISTS `tbl_pago_arriendo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pago_arriendo` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `operacion` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `metodo_pago` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  `valor_pago` int(11) NOT NULL,
  `valor_mora` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codigo`),
  KEY `metodo_pago_idx` (`metodo_pago`),
  KEY `estado_idx` (`estado`),
  KEY `operacion_idx` (`operacion`),
  CONSTRAINT `estado` FOREIGN KEY (`estado`) REFERENCES `tbl_estado_pago_arriendo` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `metodo_pago` FOREIGN KEY (`metodo_pago`) REFERENCES `tbl_metodo_pago` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `operacion` FOREIGN KEY (`operacion`) REFERENCES `tbl_operacion_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pago_arriendo`
--

LOCK TABLES `tbl_pago_arriendo` WRITE;
/*!40000 ALTER TABLE `tbl_pago_arriendo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pago_arriendo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pago_paquete`
--

DROP TABLE IF EXISTS `tbl_pago_paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pago_paquete` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `codigo_compra_paquete` int(11) NOT NULL,
  `valor` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `estado_idx` (`estado`),
  KEY `codigo_compra_paquete_idx` (`codigo_compra_paquete`),
  CONSTRAINT `codigo_compra_paquete_a` FOREIGN KEY (`codigo_compra_paquete`) REFERENCES `tbl_compra_paquete` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `estado_a` FOREIGN KEY (`estado`) REFERENCES `tbl_estado_pago_paquete` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pago_paquete`
--

LOCK TABLES `tbl_pago_paquete` WRITE;
/*!40000 ALTER TABLE `tbl_pago_paquete` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pago_paquete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pais`
--

DROP TABLE IF EXISTS `tbl_pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pais` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pais`
--

LOCK TABLES `tbl_pais` WRITE;
/*!40000 ALTER TABLE `tbl_pais` DISABLE KEYS */;
INSERT INTO `tbl_pais` (`codigo`, `nombre`) VALUES (1,'Colombia '),(2,'Ecuador'),(3,'Mexico');
/*!40000 ALTER TABLE `tbl_pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_paquete`
--

DROP TABLE IF EXISTS `tbl_paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_paquete` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_paquete`
--

LOCK TABLES `tbl_paquete` WRITE;
/*!40000 ALTER TABLE `tbl_paquete` DISABLE KEYS */;
INSERT INTO `tbl_paquete` (`codigo`, `nombre`, `valor`) VALUES (1,'Casa',100),(2,'Edificio',200),(3,'Unidad',300),(4,'Castillo',500000);
/*!40000 ALTER TABLE `tbl_paquete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_parentesco`
--

DROP TABLE IF EXISTS `tbl_parentesco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_parentesco` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_parentesco`
--

LOCK TABLES `tbl_parentesco` WRITE;
/*!40000 ALTER TABLE `tbl_parentesco` DISABLE KEYS */;
INSERT INTO `tbl_parentesco` (`codigo`, `nombre`) VALUES (1,'Abuelo(A)'),(2,'Cuñado(A)'),(3,'Esposo(A)'),(4,'Familiar Lejano'),(5,'Hermano(A)'),(6,'Hijo(A)'),(7,'Nieto(A)'),(8,'Papá / Mamá'),(9,'Primo(A)'),(10,'Sobrino(A)'),(11,'Suegro(A)'),(12,'Tío(A)'),(13,'Amigo(A)'),(14,'Niguno(A)');
/*!40000 ALTER TABLE `tbl_parentesco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_piso`
--

DROP TABLE IF EXISTS `tbl_piso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_piso` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_piso`
--

LOCK TABLES `tbl_piso` WRITE;
/*!40000 ALTER TABLE `tbl_piso` DISABLE KEYS */;
INSERT INTO `tbl_piso` (`codigo`, `nombre`) VALUES (1,'Ceramica '),(2,'Baldosa común'),(3,'Madera'),(4,'Marmol '),(5,'Retal de marmol'),(6,'Tapete'),(7,'Porcelanato '),(8,'Madera laminada'),(9,'Otros ');
/*!40000 ALTER TABLE `tbl_piso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_profesion`
--

DROP TABLE IF EXISTS `tbl_profesion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_profesion` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_profesion`
--

LOCK TABLES `tbl_profesion` WRITE;
/*!40000 ALTER TABLE `tbl_profesion` DISABLE KEYS */;
INSERT INTO `tbl_profesion` (`codigo`, `nombre`) VALUES (1,'Programador de Software'),(2,'Abogado(a)'),(3,'Administrador(a)'),(4,'Agronomo(a)'),(5,'cociner(a) / chef'),(6,'Constructor'),(7,'bombero(a)'),(8,'Doctor(a)'),(9,'Policia'),(10,'Maestro(a)'),(11,'Veterinario(a)'),(12,'Actriz / Actor'),(13,'Arquitecto (a)'),(14,'Cantante'),(15,'Dentista'),(16,'Dectective'),(17,'Escritor / escritora'),(18,'Granjero (a)'),(19,'Enferemero (a)'),(20,'Piloto'),(21,'Contador (a)'),(22,'Carnicero (a)'),(23,'Cajero'),(24,'Barberia'),(25,'Carpinteria'),(26,' Panadero (a)'),(27,'Electricista'),(28,'Asistente de vuelo'),(29,'Plomero (a)'),(30,'Fotografo (a)'),(31,'Recepcionesta'),(32,'Cientifico'),(33,'Conductor'),(34,'Dise&ntilde;ador (a)'),(35,'Periodista'),(36,'Salvavidas'),(37,'Musico'),(38,'Florista'),(39,'Asistenta de ventas'),(40,'Mecanico (a)'),(41,'Modelo'),(42,'Asistente de tienda'),(43,'Politico'),(44,'Traductor'),(45,'Peluquero (a)'),(46,'Farmaceutico (a)'),(47,'Agente de viajes'),(48,'Limpiador (a)'),(49,'Biologo (a)'),(50,'Empresario (a)'),(51,'Bailarin (a)'),(52,'Jardinero (a)'),(53,'Meteorologo (a)'),(54,'Cartero (a)'),(55,'Programador'),(56,'Ni&ntilde;ero (a)'),(57,'Guia Turistico '),(58,'Vendedor (a)'),(59,'Investigador (a)'),(60,'Bibliotecario'),(61,'Criminalista'),(62,'Fiscal'),(63,'Ingeniero'),(64,'Juez'),(65,'Oficinista'),(66,'Periodista'),(67,'psicologo'),(68,'Otro');
/*!40000 ALTER TABLE `tbl_profesion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_propiedad`
--

DROP TABLE IF EXISTS `tbl_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_propiedad` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `propietario` int(15) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `sector_barrio` int(11) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `area_total` decimal(8,2) NOT NULL,
  `area_construida` decimal(8,2) NOT NULL,
  `fecha_registro_propiedad` date NOT NULL,
  `tipo_propiedad` int(11) NOT NULL,
  `estrato` int(11) NOT NULL,
  `tipo_cocina` int(11) DEFAULT NULL,
  `tipo_piso` int(11) DEFAULT NULL,
  `estado_propiedad` int(11) NOT NULL,
  `numero_niveles` int(11) NOT NULL,
  `numero_piso` int(11) DEFAULT NULL,
  `constructora` int(11) DEFAULT NULL,
  `numero_alcoba` int(11) NOT NULL,
  `numero_bano` int(11) NOT NULL,
  `video` varchar(150) DEFAULT NULL,
  `copropiedad` int(11) DEFAULT NULL,
  `parqueadero` tinyint(1) DEFAULT NULL,
  `cuarto_util_parqueadero` tinyint(1) DEFAULT NULL,
  `destacado` tinyint(1) DEFAULT NULL,
  `visitas` int(11) DEFAULT NULL,
  `archivo_documento` varchar(45) DEFAULT NULL,
  `valor_arriendo` int(11) NOT NULL,
  `valor_venta` int(11) NOT NULL,
  `numero_matricula_inmobiliaria` varchar(15) NOT NULL,
  `nombre_carpeta` varchar(150) NOT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `numero_matricula_inmobiliaria` (`numero_matricula_inmobiliaria`),
  KEY `tipo_idx` (`tipo_propiedad`),
  KEY `usuario_idx` (`propietario`),
  KEY `piso_idx` (`tipo_piso`),
  KEY `cocina_idx` (`tipo_cocina`),
  KEY `copropiedad_idx` (`copropiedad`),
  KEY `constructora_idx` (`constructora`),
  KEY `estado_propiedad_idx` (`estado_propiedad`),
  KEY `sector_barrio_idx` (`sector_barrio`),
  CONSTRAINT `cocina` FOREIGN KEY (`tipo_cocina`) REFERENCES `tbl_cocina` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `constructora` FOREIGN KEY (`constructora`) REFERENCES `tbl_constructora` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `copropiedad` FOREIGN KEY (`copropiedad`) REFERENCES `tbl_copropiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `estado_propiedad` FOREIGN KEY (`estado_propiedad`) REFERENCES `tbl_estado_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `piso` FOREIGN KEY (`tipo_piso`) REFERENCES `tbl_piso` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `sector_barrio` FOREIGN KEY (`sector_barrio`) REFERENCES `tbl_sector_barrio` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tipo` FOREIGN KEY (`tipo_propiedad`) REFERENCES `tbl_tipo_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuario` FOREIGN KEY (`propietario`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_propiedad`
--

LOCK TABLES `tbl_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_propiedad` DISABLE KEYS */;
INSERT INTO `tbl_propiedad` (`codigo`, `propietario`, `titulo`, `descripcion`, `sector_barrio`, `direccion`, `area_total`, `area_construida`, `fecha_registro_propiedad`, `tipo_propiedad`, `estrato`, `tipo_cocina`, `tipo_piso`, `estado_propiedad`, `numero_niveles`, `numero_piso`, `constructora`, `numero_alcoba`, `numero_bano`, `video`, `copropiedad`, `parqueadero`, `cuarto_util_parqueadero`, `destacado`, `visitas`, `archivo_documento`, `valor_arriendo`, `valor_venta`, `numero_matricula_inmobiliaria`, `nombre_carpeta`) VALUES (142,1094958193,'apartamento en arriendo municipio de rionegro','RIOGRANDE HABITAT Cuenta con porterIa cerrada las 24 horas, sus zonas comunes son piscinas climatizadas, sauna, turco, sal&oacute;n social, gimnasio dotado, juegos infantiles y parqueaderos de visitantes.\r\n&lt;/p&gt;&lt;p&gt;Construido en la nueva zona de gran desarrollo urbano de Rionegro. Su privilegiada ubicaci&oacute;n hace que cuenten con una amplia vista a zonas verdes, siendo adem&aacute;s un sector muy tranquilo seguro.\r\n&lt;/p&gt;&lt;p&gt;Nuestro proyecto se encuentra a menos de 10 minutos la Cl&iacute;nica Somer, el centro comercial San Nicol&aacute;s, el Aeropuerto Internacional Jos&eacute; Mar&iacute;a C&oacute;rdoba a 18 minutos y la ciudad de Medell&iacute;n a tan solo 50 minutos, sin dejar de mencionar la cercan&iacute;a y f&aacute;cil acceso a los dem&aacute;s municipios del Oriente Antioque&ntilde;o.\r\n&lt;/p&gt;&lt;p&gt;Hermoso Apartamento para estrenar, piso 15, con parqueadero y cuarto &uacute;til, vista panoramica, sala, comedor, 3 habitaciones, 2 ba&ntilde;os cabinados, zona de ropas, gas natural, calentador de agua, balc&oacute;n.\r\n&lt;/p&gt;&lt;p&gt;Brokers Soluciones&lt;/p&gt;',1,'RIOGRANDE HABITAT',77.00,77.00,'2018-08-15',2,4,3,1,1,1,101,NULL,3,2,'NULL',1,1,1,1,NULL,NULL,1300000,0,'4439912','apartamento_en_arriendo_municipio_de_rionegro'),(144,1094958193,'apartamento en arriendo municipio de rionegro 2','Aparatamento en arriendo Municipio de Rionegro RIOGRANDE HABITAT Cuenta con porter&iacute;a cerrada las 24 horas, sus zonas comunes son piscinas climatizadas, sauna, turco, sal&oacute;n social, gimnasio dotado, juegos infantiles y parqueaderos de visitantes.\r\n&lt;/p&gt;&lt;p&gt;\r\n&lt;/p&gt;&lt;p&gt;Construido en la nueva zona de gran desarrollo urbano de Rionegro. Su privilegiada ubicaci&oacute;n hace que cuenten con una amplia vista a zonas verdes, siendo adem&aacute;s un sector muy tranquilo seguro.\r\n&lt;/p&gt;&lt;p&gt;\r\n&lt;/p&gt;&lt;p&gt;Nuestro proyecto se encuentra a menos de 10 minutos la Cl&iacute;nica Somer, el centro comercial San Nicol&aacute;s, el Aeropuerto Internacional Jos&eacute; Mar&iacute;a C&oacute;rdoba a 18 minutos y la ciudad de Medell&iacute;n a tan solo 50 minutos, sin dejar de mencionar la cercan&iacute;a y f&aacute;cil acceso a los dem&aacute;s municipios del Oriente Antioque&ntilde;o.\r\n&lt;/p&gt;&lt;p&gt;Hermoso Apartamento para estrenar, piso 15, con parqueadero y cuarto &uacute;til, vista panoramica, sala, comedor, 3 habitaciones, 2 ba&ntilde;os cabinados, zona de ropas, gas natural, calentador de agua, balc&oacute;n.&lt;/p&gt;',435,'RIOGRANDE HABITAT',77.00,77.00,'2018-08-15',2,4,3,1,1,1,103,NULL,3,2,'NULL',1,1,1,1,NULL,NULL,1300000,0,'443991','apartamento_en_arriendo_municipio_de_rionegro_2'),(145,1094958193,'apartamento en arriendo municipio de rionegro 2','APARTAMENTO EN ARRIENDO $1,300,000\r\nAparatamento en arriendo Municipio de Rionegro\r\n&lt;/p&gt;&lt;p&gt;RIOGRANDE H&Aacute;BITAT Cuenta con porter&iacute;a cerrada las 24 horas, sus zonas comunes son piscinas climatizadas, sauna, turco, sal&oacute;n social, gimnasio dotado, juegos infantiles y parqueaderos de visitantes.\r\n&lt;/p&gt;&lt;p&gt;\r\n&lt;/p&gt;&lt;p&gt;Construido en la nueva zona de gran desarrollo urbano de Rionegro. Su privilegiada ubicaci&oacute;n hace que cuenten con una amplia vista a zonas verdes, siendo adem&aacute;s un sector muy tranquilo seguro.\r\n&lt;/p&gt;&lt;p&gt;\r\n&lt;/p&gt;&lt;p&gt;Nuestro proyecto se encuentra a menos de 10 minutos la Cl&iacute;nica Somer, el centro comercial San Nicol&aacute;s, el Aeropuerto Internacional Jos&eacute; Mar&iacute;a C&oacute;rdoba a 18 minutos y la ciudad de Medell&iacute;n a tan solo 50 minutos, sin dejar de mencionar la cercan&iacute;a y f&aacute;cil acceso a los dem&aacute;s municipios del Oriente Antioque&ntilde;o.\r\n&lt;/p&gt;&lt;p&gt;\r\n&lt;/p&gt;&lt;p&gt;Hermoso Apartamento para estrenar, piso 15, con parqueadero y cuarto &uacute;til, vista panoramica, sala, comedor, 3 habitaciones, 2 ba&ntilde;os cabinados, zona de ropas, gas natural, calentador de agua, balc&oacute;n.&lt;/p&gt;',8,'RIOGRANDE HABITAT',77.00,77.00,'2018-08-15',2,4,2,3,1,1,99,NULL,3,2,'NULL',1,1,1,1,NULL,NULL,1300000,0,'443991a','apartamento_en_arriendo_municipio_de_rionegro_2_ri4t8Q'),(180,1038414938,'Venta Casa Campestre Marinilla','El entorno campestre que estabas buscando en el Municipio de Marinilla, Antioquia. Excelentes vias de acceso.\r\nCerca a todo lo que necesitas.\r\nZona BBQ\r\nVigilancia las 24 horas.\r\nCCTV\r\nSeguro Allianz\r\nReflectores nocturnos.\r\nNo paga administracion. \r\nParcelacion privada en la vereda mas exclusiva de Marinilla.\r\nVereda las Mercedes a solo 5 minutos de la autopista principal.\r\nCasa Campestre para estrenar, Estrato 3. \r\nArea de lote: 3.400 mt2\r\nArea de construccion: 180 mt2\r\nZona BBQ: 24mt2  ',8,'Las Mercedes',3400.00,120.00,'2018-01-01',5,3,1,2,1,1,1,1,2,2,NULL,NULL,1,NULL,1,NULL,NULL,0,500000000,'0000011111','casa_finca_venta_marinilla');
/*!40000 ALTER TABLE `tbl_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_propiedad_comodidad_propiedad`
--

DROP TABLE IF EXISTS `tbl_propiedad_comodidad_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_propiedad_comodidad_propiedad` (
  `codigo_propiedad` int(11) NOT NULL,
  `codigo_comodidad_propiedad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_propiedad`,`codigo_comodidad_propiedad`),
  KEY `comodidad_propiedad_idx` (`codigo_comodidad_propiedad`),
  KEY `codigo_propiedad_idx` (`codigo_propiedad`) USING BTREE,
  CONSTRAINT `comodidad_propiedad_a` FOREIGN KEY (`codigo_comodidad_propiedad`) REFERENCES `tbl_comodidad_general_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `propiedad_a` FOREIGN KEY (`codigo_propiedad`) REFERENCES `tbl_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_propiedad_comodidad_propiedad`
--

LOCK TABLES `tbl_propiedad_comodidad_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_propiedad_comodidad_propiedad` DISABLE KEYS */;
INSERT INTO `tbl_propiedad_comodidad_propiedad` (`codigo_propiedad`, `codigo_comodidad_propiedad`) VALUES (142,4),(142,8),(142,9),(144,4),(144,8),(144,9),(145,1),(145,3),(145,5),(145,7),(145,9),(180,10),(180,18),(180,23),(180,26);
/*!40000 ALTER TABLE `tbl_propiedad_comodidad_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_propiedad_compra_paquete`
--

DROP TABLE IF EXISTS `tbl_propiedad_compra_paquete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_propiedad_compra_paquete` (
  `codigo_compra_paquete` int(11) NOT NULL,
  `codigo_propiedad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_compra_paquete`,`codigo_propiedad`),
  KEY `codigo_propiedad_idx` (`codigo_propiedad`),
  CONSTRAINT `codigo_compra_paquete` FOREIGN KEY (`codigo_compra_paquete`) REFERENCES `tbl_compra_paquete` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `codigo_propiedad` FOREIGN KEY (`codigo_propiedad`) REFERENCES `tbl_propiedad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_propiedad_compra_paquete`
--

LOCK TABLES `tbl_propiedad_compra_paquete` WRITE;
/*!40000 ALTER TABLE `tbl_propiedad_compra_paquete` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_propiedad_compra_paquete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_provincia`
--

DROP TABLE IF EXISTS `tbl_provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_provincia` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `pais` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `pais_idx` (`pais`),
  CONSTRAINT `pais` FOREIGN KEY (`pais`) REFERENCES `tbl_pais` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_provincia`
--

LOCK TABLES `tbl_provincia` WRITE;
/*!40000 ALTER TABLE `tbl_provincia` DISABLE KEYS */;
INSERT INTO `tbl_provincia` (`codigo`, `nombre`, `pais`) VALUES (1,'Antioquia',1),(2,'Boyaca',1),(3,'Cundinamarca',1);
/*!40000 ALTER TABLE `tbl_provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_puntuacion`
--

DROP TABLE IF EXISTS `tbl_puntuacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_puntuacion` (
  `codigo` int(11) NOT NULL,
  `puntaje` int(11) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_puntuacion`
--

LOCK TABLES `tbl_puntuacion` WRITE;
/*!40000 ALTER TABLE `tbl_puntuacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_puntuacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_puntuacion_historial`
--

DROP TABLE IF EXISTS `tbl_puntuacion_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_puntuacion_historial` (
  `cod_puntuacion` int(11) NOT NULL,
  `cod_historial` int(11) NOT NULL,
  PRIMARY KEY (`cod_puntuacion`,`cod_historial`),
  KEY `cod_historial_idx` (`cod_historial`),
  CONSTRAINT `cod_historial` FOREIGN KEY (`cod_historial`) REFERENCES `tbl_historial` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cod_puntuacion` FOREIGN KEY (`cod_puntuacion`) REFERENCES `tbl_puntuacion` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_puntuacion_historial`
--

LOCK TABLES `tbl_puntuacion_historial` WRITE;
/*!40000 ALTER TABLE `tbl_puntuacion_historial` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_puntuacion_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_referencia`
--

DROP TABLE IF EXISTS `tbl_referencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_referencia` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_relacion` int(11) NOT NULL,
  `nombres_apellidos` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `parentesco` int(11) NOT NULL,
  `telefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `ciudad` int(11) NOT NULL,
  `direccion` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `tipo` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `usuario_rel_referencia_idx` (`usuario_relacion`),
  KEY `ciudad_referencia_idx` (`ciudad`),
  KEY `parentesco_referencia_idx` (`parentesco`),
  CONSTRAINT `ciudad_referencia` FOREIGN KEY (`ciudad`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `parentesco_referencia` FOREIGN KEY (`parentesco`) REFERENCES `tbl_parentesco` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usuario_rel_referencia` FOREIGN KEY (`usuario_relacion`) REFERENCES `tbl_usuario` (`documento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_referencia`
--

LOCK TABLES `tbl_referencia` WRITE;
/*!40000 ALTER TABLE `tbl_referencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_referencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_registro_mercantil_independiente`
--

DROP TABLE IF EXISTS `tbl_registro_mercantil_independiente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_registro_mercantil_independiente` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  `url_documento` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_registro_mercantil_independiente`
--

LOCK TABLES `tbl_registro_mercantil_independiente` WRITE;
/*!40000 ALTER TABLE `tbl_registro_mercantil_independiente` DISABLE KEYS */;
INSERT INTO `tbl_registro_mercantil_independiente` (`codigo`, `nombre`, `url_documento`) VALUES (1,'RUT',NULL),(2,'Cámara de comercio',NULL),(4,'Registro mercantil',NULL);
/*!40000 ALTER TABLE `tbl_registro_mercantil_independiente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rol`
--

DROP TABLE IF EXISTS `tbl_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rol` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(15) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rol`
--

LOCK TABLES `tbl_rol` WRITE;
/*!40000 ALTER TABLE `tbl_rol` DISABLE KEYS */;
INSERT INTO `tbl_rol` (`codigo`, `nombre`) VALUES (1,'Administrador'),(2,'Usuario ');
/*!40000 ALTER TABLE `tbl_rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sector_barrio`
--

DROP TABLE IF EXISTS `tbl_sector_barrio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sector_barrio` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `ciudad` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `ciudad_idx` (`ciudad`),
  CONSTRAINT `ciudad_a` FOREIGN KEY (`ciudad`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sector_barrio`
--

LOCK TABLES `tbl_sector_barrio` WRITE;
/*!40000 ALTER TABLE `tbl_sector_barrio` DISABLE KEYS */;
INSERT INTO `tbl_sector_barrio` (`codigo`, `nombre`, `ciudad`) VALUES (1,'San Antonio',8),(2,'Barrio Ospina',1),(3,'Buenos Aires',1),(4,'Centro',1),(5,'Don Berna',1),(6,'Las Mercedes',71),(7,'El Progreso',1),(8,'Fundadores',8),(9,'Jardines de campo alegre',1),(10,'La Alhambra',1),(11,'La Bomba',1),(12,'La Mar&iacute;a',1),(13,'Las Brisas',1),(14,'Las Manguitas',1),(15,'Los &Aacute;ngeles',1),(16,'Los Girasoles',1),(17,'Quintas de la Florida',1),(18,'San Jos&eacute;',1),(19,'San Vicente',1),(20,'Santa Cruz',1),(21,'Sector Antigua Feria',1),(22,'Sector Casa de la Cultura',1),(23,'Sector Divino Ni&ntilde;o',1),(24,'Sector El Cementerio',1),(25,'Sector El Sacat&iacute;n',1),(26,'Sector Industrial',1),(27,'Sector la Ciudadela',1),(28,'Sector los Pinos',1),(29,'Taham&iacute;es',1),(30,'Villa de las Mercedes',1),(31,'Villa Mar&iacute;a',1),(32,'Villas de As&oacute;n',1),(33,'Villas de la Modelo',1),(34,'Villas del Carmelo',1),(35,'Agua Bonita',1),(36,'Aldana',1),(37,'Belen Chaverras',1),(38,'Betania',1),(39,'Boquer&oacute;n',1),(40,'Camargo',1),(41,'Campo Alegre',1),(42,'Corales',1),(43,'Cristo Rey',1),(44,'Dos Quebradas',1),(45,'El Brazil',1),(46,'El Cerro',1),(47,'El Cipr&eacute;s',1),(48,'El Cocuyo',1),(49,'El Estio',1),(50,'El Porvenir',1),(51,'El Retiro',1),(52,'El Roblal',1),(53,'El Salado',1),(54,'Guamito',1),(55,'Guarin&oacute;',1),(56,'La Aurora',1),(57,'La Aguada',1),(58,'La Cascada',1),(59,'La Cristalina',1),(60,'La Encimada',1),(61,'La Florida',1),(62,'La Honda',1),(63,'La Linda',1),(64,'La Milagrosa',1),(65,'La Palma',1),(66,'La Represa',1),(67,'Las Garzonas',1),(68,'Las Acacias',1),(69,'Mazorcal',1),(70,'Mirasol',1),(71,'Morros',1),(72,'Palizadas',1),(73,'Quirama',1),(74,'Rivera',1),(75,'Samaria',1),(76,'San Eusebio',1),(77,'San Jos&eacute;',1),(78,'San Lorenzo',1),(79,'San Vicente',1),(80,'Santa Ana',1),(81,'Santo Domingo',1),(82,'Sonadora',1),(83,'Vallejuelito',1),(84,'Viboral',1),(85,'Camilo C',5),(86,'La Clarita',5),(87,'Minas',5),(88,'El Cedro',5),(89,'El Morro',5),(90,'Guaimaral',5),(91,'La Delgadita',5),(92,'La Ferrer&iacute;a',5),(93,'La Gual&iacute;',5),(94,'Malabrigo',5),(95,'Mani de las Mangas',5),(96,'Mani del Cardal',5),(97,'Nech&iacute;',5),(98,'Nicanor Restrepo',5),(99,'Pasonivel Las Pe&ntilde;as',5),(100,'Piedecuesta',5),(101,'Pueblito De Los Bolivares',5),(102,'Pueblito De Los S&aacute;nches',5),(103,'Pueblito D e San Jos&eacute;',5),(104,'Trraves&iacute;as',5),(105,'Yarumal',5),(106,'Altamarina',2),(107,'Alto Bonito',2),(108,'Alto de Letras',2),(109,'Aures Ariba',2),(110,'Aures El Silencio',2),(111,'Canaverales ',2),(112,'Carrizales',2),(113,'Chagualal',2),(114,'Combia',2),(115,'Corinto',2),(116,'El Buey',2),(117,'El Carmelo',2),(118,'El caunzal ',2),(119,'El Chagualo',2),(120,'El Erizo',2),(121,'El Granadillo',2),(122,'El Guaico',2),(123,'Guarango',2),(124,'Guayabal',2),(125,'Guayaquil',2),(126,'La Betulla',2),(127,'La Cascada',2),(128,'La Circita',2),(129,'La Cordillera',2),(130,'La esperanza',2),(131,'La Florida',2),(132,'La Labor',2),(133,'La Loma',2),(134,'La Nuvia',2),(135,'La Pena',2),(136,'La Perdida',2),(137,'La Polka',2),(138,'La Primavera',2),(139,'La Saltadera',2),(140,'La Samaria',2),(141,'La Victoria',2),(142,'Llanadas',2),(143,'Llanogrande',2),(144,'Los Rastrojos',2),(145,'Mata de Guadua',2),(146,'Monte Loro',2),(147,'Morrogordo',2),(148,'Naranjal',2),(149,'Pantanillo',2),(150,'Pantano Negro',2),(151,'Piedra Candela',2),(152,'Portugal',2),(153,'Purima',2),(154,'Quebradanegra',2),(155,'Quebradona',2),(156,'San Bartolo',2),(157,'San Bernardo',2),(158,'San Jose',2),(159,'San Luis',2),(160,'San Pedro',2),(161,'San Vicente',2),(162,'Santa Ana',2),(163,'Santa Catalina',2),(164,'Sotayac',2),(165,'Yarumal',2),(166,'Cruces',4),(167,'El Carbon',4),(168,'El Cerro',4),(169,'El Popo',4),(170,'El Respaldo',4),(171,'Embalse Pe&ntilde;ol',4),(172,'Pe&ntilde;ol',4),(173,'Embalse San Lorenzo',4),(174,'La Inmaculada',4),(175,'La Pava',4),(176,'Piedras',4),(177,'Remolino',4),(178,'San Jose',4),(179,'San Lorenzo',4),(180,'San Miguel',4),(181,'San Pedro',4),(182,'Tocaima ',4),(183,'Alto Canaveral',7),(184,'Alto Canaveral',7),(185,'Altos del Rayo',7),(186,'Alto Senon',7),(187,'Bajo Ca&ntilde;averal',7),(188,'Buenos Aires',7),(189,'California',7),(190,'Cascajero',7),(191,'Chaparralito',7),(192,'Egipto',7),(193,'El Barcino',7),(194,'El Cardal',7),(195,'El Cedr&oacute;n',7),(196,'El Chispero',7),(197,'El Crucero',7),(198,'El Ignacio',7),(199,'El Libano',7),(200,'El Rojo',7),(201,'El Tapado',7),(202,'Guaimaral',7),(203,'La Aguada',7),(204,'La Argentina',7),(205,'La Avanzada',7),(206,'La Bodega',7),(207,'La Borraja',7),(208,'La Cedrona',7),(209,'La Clara',7),(210,'La Comuna',7),(211,'La Cristalina',7),(212,'La Ermita',7),(213,'La Legia',7),(214,'La Manuela',7),(215,'La Masenla',7),(216,'La Piedra',7),(217,'La Pradera',7),(218,'La Rochela',7),(219,'La Siria',7),(220,'La Soledad',7),(221,'La Solita',7),(222,'Las Colonias',7),(223,'Las Flores',7),(224,'Media Luna',7),(225,'Monte Blanco',7),(226,'Monte Verde',7),(227,'Orizaba',7),(228,'Palestina',7),(229,'Reserva Forestal',7),(230,'Rio Claro',7),(231,'Risaralda',7),(232,'San Agustin',7),(233,'San Antonio',7),(234,'San Bartolo',7),(235,'San Carlos',7),(236,'San Fernando',7),(237,'San Gregorio',7),(238,'San Jose',7),(239,'San Juli&aacute;n',7),(240,'San Miguel',7),(241,'San Pedro',7),(242,'San Perucho',7),(243,'Santa Elena',7),(244,'Santa Ines',7),(245,'Santa Rita',7),(246,'Taparto',7),(247,'Valle Umbria',7),(248,'Yarumal',7),(249,'Bellavista',11),(250,'Bol&iacute;var',11),(251,'Brisas del Nech&iacute;',11),(252,'Chagualito',11),(253,'Chagualo',11),(254,'Concha Abajo',11),(255,'Concha Arriba',11),(256,'Concha Media',11),(257,'Cruces',11),(258,'Dos Bocas',11),(259,'El Banco',11),(260,'El Carmen',11),(261,'El Carm&iacute;n',11),(262,'El Limon',11),(263,'El Retiro',11),(264,'El Roble',11),(265,'El Zafiro',11),(266,'La Casita',11),(267,'La Cristalina',11),(268,'La Esperanza',11),(269,'La Guayana',11),(270,'La Meseta',11),(271,'La Plancha',11),(272,'La Primavera',11),(273,'La Soledad',11),(274,'La Teresita',11),(275,'La Trinidad',11),(276,'Las A&acute;nimas',11),(277,'Las Lomitas ',11),(278,'Las Nieves',11),(279,'Liberia',11),(280,'Los Trozos',11),(281,'Madreseca',11),(282,'Medias Faldas',11),(283,'Miraflores',11),(284,'Montebello',11),(285,'Montefr&iacute;o',11),(286,'Pajonal',11),(287,'Providencia',11),(288,'Puerto Rico',11),(289,'Roble Arriba',11),(290,'San Isidro',11),(291,'San Juan',11),(292,'San Lorenzo',11),(293,'Santa Gertrudis',11),(294,'Santa Ines',11),(295,'Santiago',11),(296,'Santo Domingo',11),(297,'Solano',11),(298,'Tabacal',11),(299,'Travesias',11),(300,'Villa Fatima',11),(301,'El Encanto',12),(302,'El Pedrero',12),(303,'Guintar',12),(304,'Higuina',12),(305,'La Cejita',12),(306,'La Choclina',12),(307,'La Chuscalito',12),(308,'La Cienaga',12),(309,'La Cordillera',12),(310,'La Mata',12),(311,'La Quiebra',12),(312,'Las Lomitas',12),(313,'Los Llanos',12),(314,'Monterredondo',12),(315,'Nudillo',12),(316,'Quiuna',12),(317,'Valerio',12),(318,'Vendiagual',12),(319,'Arenas Alta',13),(320,'Arenas  Bajas',13),(321,'Bajo del oso',13),(322,'Bella Vista',13),(323,'Buenos Aires',13),(324,'Churrido',13),(325,'Churrido Medio',13),(326,'Churrido Puente',13),(327,'Churrido Sinai',13),(328,'El Cuchillo',13),(329,'El Diamante',13),(330,'EL Gas',13),(331,'El Guaro',13),(332,'El Guineo',13),(333,'El Osito',13),(334,'El Porvenir',13),(335,'El Reposo',13),(336,'El Salto',13),(337,'El Salvador',13),(338,'El Tigre',13),(339,'Guineo Alto',13),(340,'La Balsa',13),(341,'La Cristalina',13),(342,'La Danta',13),(343,'La Esperanza',13),(344,'La Hoz',13),(345,'La Linda',13),(346,'La Miranda',13),(347,'La Pancha',13),(348,'La Pedrosa',13),(349,'La Resbalosa',13),(350,'La Union',13),(351,'La victoria',13),(352,'Las Flores',13),(353,'Las Nieves',13),(354,'Las Playas',13),(355,'Los Mandarinos',13),(356,'Los Naranjales',13),(357,'Miramar',13),(358,'Mulatos Cabecera',13),(359,'Mulatos Medio',13),(360,'Playa Larga',13),(361,'Puerto Caribe',13),(362,'Punto Rojo',13),(363,'Rodoxali',13),(364,'Sabaleta',13),(365,'Salsipuedes',13),(366,'San Jose de Apartado',13),(367,'San Martin',13),(368,'San Pablo',13),(369,'Vijagual',13),(370,'Zungo Abajo',13),(371,'Zungo Arriba',13),(372,'Zubgo Carrretera',13),(373,'Atoyosa',13),(374,'Bajo Grande',14),(375,'Bajos la Arenosa',14),(376,'Barrrancuda',14),(377,'Boca al Rev&eacute;s',14),(378,'Buenos Aires',14),(379,'Cajones',13),(380,'Calabozo',14),(381,'Ccanpanito',14),(382,'Canime',14),(383,'Cerro de las Lajas',14),(384,'El Carmelo',14),(385,'El Bonguito',14),(386,'El Caucho',14),(387,'El Coco',14),(388,'El Guadual',14),(389,'El Guadual del Medio',14),(390,'El Guaimaro',14),(391,'El Inglesito',13),(392,'El Porvenir',14),(393,'El Socorro',14),(394,'El Tambo',14),(395,'El volcan',14),(396,'El Volcancito',14),(397,'El Yeso',14),(398,'Filo de Venus',14),(399,'Garrapata',14),(400,'Guadual Abajo',14),(401,'Holanda',14),(402,'La Arenosa',14),(403,'La Candelaria',14),(404,'La Caridad',13),(405,'La Mesa',14),(406,'La Trinidad',14),(407,'La Velez',14),(408,'Las Lanas',14),(409,'Las Naranjitas',14),(410,'Las Patillas',14),(411,'Las Pavitas',13),(412,'Las Plantas',14),(413,'Marcella',14),(414,'Nueva Florida',14),(415,'Nuevo Oriente',14),(416,'Pajillal',14),(417,'Pangola',14),(418,'Paraido',14),(419,'Pelayo',14),(420,'Piedrecitas',14),(421,'Plan Parejo',14),(422,'Plantas Arriba',14),(423,'Plantas del Medio',14),(424,'Pueblo Chino',14),(425,'San Carlos',14),(426,'San Jose',14),(427,'San Juancito  Vijao',14),(428,'San Rafael',14),(429,'Siete Hernanas',14),(430,'Trementino',14),(431,'Arbolitos',15),(432,'Catagueno',15),(433,'El Socorro',15),(434,'La Herradura',15),(435,'La Horcona|',15),(436,'La Loma',15),(437,'La Pescadora',15),(438,'La Quiebra',15),(439,'Palmichal',15),(440,'Palo Blanco',15),(441,'Travesias',15),(442,'Barlovento',20),(443,'Bellavista',20),(444,'Cajones',20),(445,'El Contento',20),(446,'El Tablazo',20),(447,'El troya',20),(448,'Guadualejo',20),(449,'Guarico',20),(450,'Hermosa',20),(451,'La Irene',20),(452,'La Italia',20),(453,'La Ladera',20),(454,'La Libia',20),(455,'La Linnda',20),(456,'La Rochela',20),(457,'La Sucia',20),(458,'Las Animas',20),(459,'Los Aguacates',20),(460,'Media luna',20),(461,'Mercedes',20),(462,'Pedral Abajo',20),(463,'Pedral Arriba',20),(464,'Primavera',20),(465,'Santa Ana',20),(466,'Taparto',20),(467,'Travesias',20),(468,'Alto del Obispo',23),(469,'Bubara',23),(470,'Buena Vista',23),(471,'Carauquia',23),(472,'Chuchunco',23),(473,'Conejos',23),(474,'Costas',23),(475,'El Leon',23),(476,'El Naranjo',23),(477,'El Puerto',23),(478,'El Siento',23),(479,'Guadual',23),(480,'Guarco',23),(481,'Higabra',23),(482,'La Angelina',23),(483,'La Cordillera',23),(484,'La Fragua',23),(485,'La Palma',23),(486,'La Vega',23),(487,'Las Brisas',23),(488,'Las Cuatro',23),(489,'Llano Chiquito',23),(490,'Llano Grande',23),(491,'Llanos de Urarco',23),(492,'Los Arados ',23),(493,'Los Asientos',23),(494,'Mogotes ',23),(495,'Murrapal',23),(496,'Pajarito',23),(497,'Palenque',23),(498,'Santa Tereza',23),(499,'Siara',23),(500,'Sopetransito',23),(501,'Tabacal',23),(502,'Unti',23),(503,'Altavista',25),(504,'Anocozca',25),(505,'Asesi',25),(506,'Bella Aguada',25),(507,'Chochal',25),(508,'El Encanto',25),(509,'El Hato',25),(510,'El Playon',25),(511,'El Tambor',25),(512,'La Cascajala',25),(513,'La Cortada',25),(514,'La Garcia',25),(515,'La Manga',25),(516,'La Noque',25),(517,'La Salazar',25),(518,'La  Soledad',25),(519,'Los Pinos',25),(520,'Los Sauces',25),(521,'San Juan',25),(522,'Barrios Unidos',26),(523,'Los Cerezos',26),(524,'Cristo Rey',26),(525,'Olaya Herrera',26),(526,'La Docena',26),(527,'La Inmaculada',26),(528,'Felipe Echavarr&iacute;a ',26),(529,'La Chuscala',26),(530,'La Planta',26),(531,'Las Margaritas',26),(532,'La Rivera',26),(533,'Zona Centro',26),(534,'Andaluc&iacute;a',26),(535,'La Goretti',26),(536,'El Socorro',26),(537,'Juan XXIII',26),(538,'Villa Capri',26),(539,'La Buena Esperanza',26),(540,'Fundadores',26),(541,'Centenario',26),(542,'Mandalay',26),(543,'La Playita',26),(544,'Bellavista',26),(545,'El Porvenir',26),(546,'La Tolva',26),(547,'Aguacatala',26),(548,'El Cano',26),(549,'La Raya',26),(550,'Primavera',26),(551,'La Corrala',26),(552,'La Miel',26),(553,'La Valeria',26),(554,'Potrerillo',26),(555,'La Man&iacute; de Carda',26),(556,'Sin&iacute;fana',26),(557,'Cardalito',26),(558,'Salinas',26),(559,'La Salada',26),(560,'La Clara',26),(561,'La Quiebra',26),(562,'La Chuscala',26),(563,'El Raizal',26),(564,'Minas',26),(565,'Minuto de Dios',26),(566,'Ca&ntilde;averal',27),(567,'Capotal',27),(568,'Caracolal',27),(569,'Chaquiral',27),(570,'El Barcino',27),(571,'El Bosque',27),(572,'Alfonso Lopez',29),(573,'Arenales',29),(574,'Carlos  E Restrepo',29),(575,'Carrilera Abajo',29),(576,'El Comercio',29),(577,'El Sol',29),(578,'Fondo Obrero',29),(579,'La Bascula',29),(580,'La Clavellina',29),(581,'La Feria',29),(582,'Los Limones',29),(583,'Palanquero',29),(584,'Santander',29),(585,'Botijas',29),(586,'Canalones',29),(587,'Cascaron',29),(588,'El 62',29),(589,'El Bagre',29),(590,'El Buey',29),(591,'El Pital',29),(592,'La Cortada',29),(593,'La Maria',29),(594,'La Mesa',29),(595,'Las Anguilas',29),(596,'Quebradona',29),(597,'Santa Isabel',29),(598,'Sardinas',29),(599,'Berrio',30),(600,'Ricaurte',30),(601,'La Pola',30),(602,'Girardot',30),(603,'Santander',30),(604,'Montoya',30),(605,'Gomez Botero',30),(606,'La Modelo',30),(607,'Fundadores',30),(608,'Leticia',30),(609,'Cordoba',30),(610,'Bolibar',30),(611,'Ospina ',30),(612,'Ospina',30),(613,'Antonio Santos',30),(614,'Aguadita Chiquita',30),(615,'Aguadita Grande',30),(616,'Buenos Aires',30),(617,'Ca&ntilde;as',30),(618,'La Esmeralda',30),(619,'La Frisolera',30),(620,'La Sirena',30),(621,'La Union',30),(622,'Manzanares',30),(623,'Naranjal',30),(624,'Olivales',30),(625,'Palmichal',30),(626,'San Antonio',30),(627,'San Jose',30),(628,'San pablo',30),(629,'Yarumalito',30),(630,'Aguas Claras',16),(631,'Altamira',16),(632,'Buga',16),(633,'Cestillal',16),(634,'Chorrohondo',16),(635,'Corrientes',16),(636,'Dos Quebradas',16),(637,'El Cortado',16),(638,'El Guayabo',16),(639,'El Hoyo ',16),(640,'El Paraiso',16),(641,'El Salado',16),(642,'El Tablazo Hatillo',16),(643,'El Tigre',16),(644,'El Viento',16),(645,'Filoverde',16),(646,'Graciano',16),(647,'Guayabal',16),(648,'Isaza',16),(649,'La Aguada',16),(650,'La Calda',16),(651,'La Cejita',16),(652,'La Chorrera',16),(653,'La Cuesta',16),(654,'La Ese',16),(655,'La Herradura',16),(656,'La Monta&ntilde;ita',16),(657,'La Montera',16),(658,'La Playa',16),(659,'La Primavera',16),(660,'La Quiebra',16),(661,'La Tolda',16),(662,'Las Lajas',16),(663,'Las Pe&ntilde;as',16),(664,'Las Victorias ',16),(665,'Matasanos',16),(666,'Mocoronguito',16),(667,'Monte',16),(668,'Monterredondo',16),(669,'Pachohondo',16),(670,'Pantanillo',16),(671,'Platanito',16),(672,'Potrerito',16),(673,'Quintero',16),(674,'San Eugenio',16),(675,'Tamborcito',16),(676,'Ventanas',16),(677,'Volantil',16),(678,'Alto Bonito',31),(679,'Belencito',31),(680,'Bijagual',31),(681,'Bocas de chigorod&oacute;',31),(682,'Campamento',31),(683,'Caracoli',31),(684,'Carepita',31),(685,'Casa Verde',31),(686,'Chirido',31),(687,'El Cerro',31),(688,'El Encanto',31),(689,'El Palmar',31),(690,'El Tagual',31),(691,'Ipankay',31),(692,'La Cadena',31),(693,'La Cristalina',31),(694,'La Danta',31),(695,'La Union',31),(696,'Las Quinientas',31),(697,'Las Trecientas',31),(698,'Miramar',31),(699,'Nueva Esperanza',31),(700,'Piedras Blancas',31),(701,'Polines San Sebastian',31),(702,'Remedia Pobre',31),(703,'Vijagual Medio',31),(704,'Zarabanda',31),(705,'Zungo Carepita',31),(706,'Zungo Embarcadero',31),(707,'Bella Palmira',33),(708,'Caceri',33),(709,'Campo Alegre',33),(710,'Cuturu',33),(711,'El Almedro',33),(712,'El Brasil',33),(713,'El  Descanso',33),(714,'El Kilometro 18',33),(715,'El Man',33),(716,'El Palomar',33),(717,'El Pando',33),(718,'El Tigre',33),(719,'El Toro',33),(720,'Guatinajo',33),(721,'Jagua Arrriba',33),(722,'La Arenosa',33),(723,'La Caseta',33),(724,'La Catalina',33),(725,'La Corcobada',33),(726,'La Escuela',33),(727,'La Esmeralda',33),(728,'La Garrapata',33),(729,'La Gloria',33),(730,'La Ilusi&oacute;n',33),(731,'La Jagua',33),(732,'La Raya',33),(733,'La Virgen',33),(734,'Las Batatas',33),(735,'Las Malvinas',33),(736,'Las Negras',33),(737,'Las Parcelas',33),(738,'Los Mangos',33),(739,'Margeto',33),(740,'Palanca',33),(741,'Palomar',33),(742,'Puerto Colombia',33),(743,'Puerto Gloria',33),(744,'Puerto Triana',33),(745,'Quebradora Arriba',33),(746,'Quebradora del Medio',33),(747,'Quitasol',33),(748,'Rio Viejo',33),(749,'Santa Rosita',33),(750,'Veracruz',33),(751,'Barranquillita',34),(752,'Bocas de Guapa',34),(753,'Champitas',34),(754,'Chigorodocito',34),(755,'Chirid&oacute;',34),(756,'El Coco',34),(757,'El Congo',34),(758,'El Dos',34),(759,'El Guineo',34),(760,'El Platano',34),(761,'El Tigre',34),(762,'El  Venado',34),(763,'El Vijao',34),(764,'Guapas',34),(765,'Guapa Arriba',34),(766,'Jurado',34),(767,'Jurado Arriba',34),(768,'La Candelaria',34),(769,'La Fe',34),(770,'La India',34),(771,'La Lucita',34),(772,'La Maporita',34),(773,'La Rivera',34),(774,'Las Mercedes',34),(775,'Malang&oacute;n',34),(776,'Polines',34),(777,'Puerto Rico',34),(778,'Quebrada Honda',34),(779,'Remigio',34),(780,'Ripea',34),(781,'Sadem',34),(782,'Serrania de Abibe',34),(783,'Bella F&aacute;tima',35),(784,'Bellavista',35),(785,'Campo Alegre',35),(786,'Cruces',35),(787,'El Brasil',35),(788,'El Caldillo',35),(789,'El Dos',35),(790,'El Lim&oacute;n',35),(791,'El Silencio',35),(792,'Palmira',35),(793,'Sabanalarga',35),(794,'San Victorino',35),(795,'Santa Ana',35),(796,'Santa Elena',35),(797,'Alfonzo Lopez',36),(798,'Amaranto',36),(799,'Bolivar Arriba',36),(800,'Buenavista',36),(801,'Farallones',36),(802,'La Angostura',36),(803,'La Arboleda',36),(804,'La Carmina',36),(805,'La Granja',36),(806,'La Hondura',36),(807,'La Linda',36),(808,'La Lindaja',36),(809,'La Sucia',36),(810,'Los Billares',36),(811,'Los Monos',36),(812,'Manzanillo',36),(813,'Remolino',36),(814,'San Miguel',36),(815,'Sucia Indigena',36),(816,'Agua Bonita',37),(817,'Agualinda',37),(818,'Alto Bonito',37),(819,'Alto de la Virgen',37),(820,'Balcones',37),(821,'Buenos Aires',37),(822,'Campo Alegre',37),(823,'Caracoli',37),(824,'Cebadero',37),(825,'Cruces',37),(826,'Cuchilla del Rejo',37),(827,'El Choco',37),(828,'El Cipres',37),(829,'El Coco',37),(830,'El Cocuyo',37),(831,'El Entablado',37),(832,'El Estio',37),(833,'El Higero',37),(834,'El Molino',37),(835,'El Palmar',37),(836,'El Porvenir',37),(837,'El Recreo',37),(838,'El Retiro',37),(839,'El Roblal',37),(840,'El Salado',37),(841,'El Sinal',37),(842,'El Suspiro',37),(843,'El Tesoro',37),(844,'El Viadal',37),(845,'El Viao',37),(846,'Guayabal',37),(847,'La Aurora',37),(848,'La Chonta',37),(849,'La Chorrera',37),(850,'La Cima',37),(851,'La Florida',37),(852,'La Granja',37),(853,'La Inmaulada',37),(854,'La Milagrosa',37),(855,'La Paila',37),(856,'La Palma',37),(857,'La Pena',37),(858,'La Pinuela',37),(859,'La Placeta',37),(860,'La Primavera',37),(861,'La Primavera',37),(862,'La Quiebra',37),(863,'La Secreta',37),(864,'La Solita',37),(865,'La Tolda',37),(866,'La Trinidad',37),(867,'La Vega',37),(868,'La Veta',37),(869,'Las Mercedes',37),(870,'Las Playas',37),(871,'Los Cedros',37),(872,'Los Limones',37),(873,'Los Mangos',37),(874,'Los Patrones',37),(875,'Majagual',37),(876,'Mazotes',37),(877,'Mediacuesta',37),(878,'Montanita',37),(879,'Morritos',37),(880,'Pailania',37),(881,'Palmirita',37),(882,'San Antonio',37),(883,'San Jose',37),(884,'San Juan ',37),(885,'San Miguel',37),(886,'San Vicente',37),(887,'Santa Barbara',37),(888,'Santa Cruz',37),(889,'Santa Rita',37),(890,'Santo Domingo',37),(891,'Villa Hermosa',37),(892,'Arango',38),(893,'Barro Blanco',38),(894,'El Relampago',38),(895,'Embalse pe&ntilde;ol',38),(896,'La Candelaria',38),(897,'La Cejita',38),(898,'La Clara',38),(899,'La Fatima',38),(900,'La Palma',38),(901,'La Piedad',38),(902,'La Sonora',38),(903,'La  Trinidad',38),(904,'Las Frias',38),(905,'Las Mercedes',38),(906,'Morro Reyes',38),(907,'Palmichal',38),(908,'Pelaez',38),(909,'San Bertolome',38),(910,'San Juan Alto',38),(911,'San Juan Llano',38),(912,'Santa Ana',38),(913,'Santa Gertrudis',38),(914,'Tafetanes',38),(915,'Burgos',39),(916,'El Cascajo',39),(917,'El Chocho',39),(918,'El Golpe',39),(919,'El Higueron',39),(920,'El Socorro',39),(921,'La  Comia',39),(922,'La Costa',39),(923,'La Cristalina',39),(924,'La Fotuta',39),(925,'La Herradura',39),(926,'La Selva',39),(927,'Las Animas',39),(928,'Llanaditas',39),(929,'Morelia',39),(930,'Moritos',39),(931,'Morron',39),(932,'Pueblo Rico',39),(933,'Rumbadero',39),(934,'Salazar',39),(935,'San Luis',39),(936,'Santa Rita',39),(937,'Ventanas',39),(938,'Yarumal',39),(939,'Agualinda',41),(940,'Alto Bonito',41),(941,'Amparrado',41),(942,'Anta',41),(943,'Antado',41),(944,'Argelia',41),(945,'Baldios de la Nacion',41),(946,'Barrancas',41),(947,'Barrancon',41),(948,'Barrancon Antado',41),(949,'Betalia',41),(950,'Boton',41),(951,'Ca&ntilde;averales',41),(952,'Carra',41),(953,'Chachafrutal',41),(954,'Chamuscado',41),(955,'Chever',41),(956,'Chichirrido',41),(957,'Chimurro',41),(958,'Chino de Playones',41),(959,'Chontaduro',41),(960,'Choromando',41),(961,'Chupadero',41),(962,'Churrascal',41),(963,'Chuscal de Murri',41),(964,'Chuscal Tuguridocito',41),(965,'Corcobado',41),(966,'Cuchillon',41),(967,'Culatrillales',41),(968,'Dabeiba Viejo',41),(969,'El Aguila',41),(970,'El Balso',41),(971,'El Boton',41),(972,'El Caliche',41),(973,'El Cocal',41),(974,'El Encierro',41),(975,'El Espinazo',41),(976,'El Jardin',41),(977,'El Jiguero',41),(978,'El Jordan',41),(979,'El Mango',41),(980,'El Mohan',41),(981,'El Paramo',41),(982,'El Pital',41),(983,'El Plan',41),(984,'El Retiro',41),(985,'El Terco',41),(986,'El Toro',41),(987,'Filo de la Cruz',41),(988,'Guadalito',41),(989,'Guineales',41),(990,'Jenaturado',41),(991,'Julio Chiquito',41),(992,'La Argelia',41),(993,'La Armenia',41),(994,'La Balsita',41),(995,'La  Chiquita',41),(996,'La Clara',41),(997,'La Danta',41),(998,'La Estrella',41),(999,'La Falda',41),(1000,'La Florida',41),(1001,'La Fortuna',41),(1002,'La Mesa',41),(1003,'La Monta&ntilde;ita',41),(1004,'La Paloma',41),(1005,'La Pla ',41),(1006,'La Soledad',41),(1007,'Las Cruces',41),(1008,'Llano Grande',41),(1009,'Llanon',41),(1010,'Los Cocos',41),(1011,'Los Naranjos',41),(1012,'Monos la Horqueta',41),(1013,'Nudillales',41),(1014,'Palmichales',41),(1015,'Palonegro',41),(1016,'Pegado',41),(1017,'Playones',41),(1018,'Pueblecito',41),(1019,'Quiparado',41),(1020,'Quiparadosito',41),(1021,'San Agustin',41),(1022,'San Ignacio',41),(1023,'San Jose de Uraba',41),(1024,'Santa Tereza',41),(1025,'Taparales',41),(1026,'Tascon',41),(1027,'Tasido',41),(1028,'Tocunal',41),(1029,'Tugurido',41),(1030,'Vallesi',41),(1031,'Alto el Brasil',43),(1032,'Arenales',41),(1033,'Blanquizal',43),(1034,'Bosque Naranjo',43),(1035,'Campo Alegre',43),(1036,'Chachafruto',43),(1037,'Comunidad',43),(1038,'El Brasil',43),(1039,'El  Cedro',43),(1040,'El Palon',43),(1041,'El Rertiro',43),(1042,'El Socorro',43),(1043,'Fatima',43),(1044,'Filo de los Arboledas',43),(1045,'Filo de San Jose',43),(1046,'Guayabal',43),(1047,'La Aguada',43),(1048,'La Clara',43),(1049,'La Esmeralda',43),(1050,'La Quiebra',43),(1051,'La Renta',43),(1052,'La Suiza',43),(1053,'Las Brisas',43),(1054,'Llano de la Santa Barbara',43),(1055,'Los Plomos',43),(1056,'Murrapal',43),(1057,'Nari&ntilde;o',43),(1058,'Quirimara Placitas',43),(1059,'Quirimara Rodeo',43),(1060,'Sagua',43),(1061,'Santander',43),(1062,'Sevilla',43),(1063,'Zarzal',43),(1064,'Bonilla',45),(1065,'Chiquinquira',45),(1066,'Concordia',45),(1067,'Despensas',45),(1068,'El Carmelo',45),(1069,'El Chilco',45),(1070,'El Marial',45),(1071,'El Morro',45),(1072,'El Salto',45),(1073,'El Uvital',45),(1074,'Embalse Pe&ntilde;ol',45),(1075,'Guamito',45),(1076,'Horizontes',45),(1077,'El Chapa',45),(1078,'La Cristalina',45),(1079,'La Culebra',45),(1080,'La Helida',45),(1081,'La Meseta',45),(1082,'Magdalena',45),(1083,'Palestina',45),(1084,'Primavera',45),(1085,'Santa Ana',45),(1086,'Santa Ines',45),(1087,'Amapola',46),(1088,'Carrizales',46),(1089,'Don Diego',46),(1090,'El Barcino',46),(1091,'El Carmen',46),(1092,'El Chuscal',46),(1093,'El Portento',46),(1094,'La Fe',46),(1095,'La Honda',46),(1096,'La  Luz',46),(1097,'Lejos del Nido',46),(1098,'Los Medios',46),(1099,'Los Salados',46),(1100,'Nazareth',46),(1101,'Normandia',46),(1102,'Pantanillo',46),(1103,'Puente Pelaez',46),(1104,'Santa Elena',46),(1105,'Tabacal',46),(1106,'Aldana',47),(1107,'Alto de Palmar',47),(1108,'Bodegas',47),(1109,'Buenavista',47),(1110,'Campo Alegre',47),(1111,'Cuchillas',47),(1112,'El Carmelo',47),(1113,'El Morro',47),(1114,'El Retiro',47),(1115,'El Saladito',47),(1116,'El Salto',47),(1117,'El Se&ntilde;or Caido',47),(1118,'El Socorrro',47),(1119,'Guadualito',47),(1120,'La Aurora',47),(1121,'La Chapa',47),(1122,'La Floresta',47),(1123,'La  Paz',47),(1124,'La Serrania',47),(1125,'La Teneria',47),(1126,'Las Lajas',47),(1127,'Las Palmas',47),(1128,'Lourdes',47),(1129,'Morritos',47),(1130,'Palmarcito',47),(1131,'Pantanillo',47),(1132,'Pavas',47),(1133,'Portachuelo',47),(1134,'Potrerito',47),(1135,'San Eugenio',47),(1136,'San Matias',47),(1137,'San Matias La Trinidad',47),(1138,'Valle La Maria',47),(1139,'Valle Luna',47),(1140,'Vargas',47),(1141,'El Filo',48),(1142,'El Pe&ntilde;ol',48),(1143,'El Progreso',48),(1144,'El Zancudo',48),(1145,'Embalse Riogrande',48),(1146,'Las  Brisas',48),(1147,'Pio XII',48),(1148,'Rio Chico',48),(1149,'Rio Grande',48),(1150,'Tesorero',48),(1151,'Toruro',48),(1152,'Yerbabuena',48),(1153,'Las Vegas',49),(1154,'Las  Casitas',49),(1155,'Primavera',49),(1156,'Vallejuelos',49),(1157,'Alcal&aacute;',49),(1158,'El Portal',49),(1159,'San Marcos',49),(1160,'Jardines',49),(1161,'Villagrande',49),(1162,'Loma del Barro',49),(1163,'La Paz',49),(1164,'El Trian&oacute;n',49),(1165,'Las Antillas',49),(1166,'San Rafael',49),(1167,'La Mina',49),(1168,'El Salado',49),(1169,'El Chingu&iacute;',49),(1170,'San Jos&eacute;',49),(1171,'El Dorado',49),(1172,'Zona Centro',49),(1173,'Mesa',49),(1174,'Loma de las Brujas',49),(1175,'La Pradera',49),(1176,'Los Naranjos',49),(1177,'El Obrero',49),(1178,'Bucarest',49),(1179,'La Magnolia',49),(1180,'Pontevenda',49),(1181,'La Orquidea',49),(1182,'La Orquidea',49),(1183,'Zu&ntilde;iga',49),(1184,'Alto de Misael',49),(1185,'Las Flores',49),(1186,'Uribe Angel',49),(1187,'La Sebastiana',49),(1188,'Inmaculada',49),(1189,'El Chocho',49),(1190,'Loma el Atravezado',49),(1191,'El Esmeraldal',49),(1192,'Aguacatal',50),(1193,'Alto de los Fernandez',50),(1194,'Buenos Aires',50),(1195,'Cadenas',50),(1196,'Chamuscados',50),(1197,'Combla Chiquita',50),(1198,'Combla Grande',50),(1199,'El Calvario',50),(1200,'El Carretero',50),(1201,'El Cinco',50),(1202,'El Mango',50),(1203,'El Molino',50),(1204,'El Plan',50),(1205,'El Porvenir',50),(1206,'El Uvital',50),(1207,'El Vainillo',50),(1208,'El Zancudo',50),(1209,'Hoyo Frio',50),(1210,'Jonas',50),(1211,'La Cordillera',50),(1212,'La Garrucha',50),(1213,'La Loma',50),(1214,'La Maria',50),(1215,'La Mina',50),(1216,'La Quiebra',50),(1217,'La Toscana',50),(1218,'Marsella',50),(1219,'Morron',50),(1220,'Morron',50),(1221,'Murrapal',50),(1222,'Naranja Poblanco',50),(1223,'Palomos',50),(1224,'Piedra Verde',50),(1225,'Puente Iglesias',50),(1226,'Raiceros',50),(1227,'Sabaletas',50),(1228,'Travesias',50),(1229,'Cuajaron',52),(1230,'El Aguila',52),(1231,'El Balso',52),(1232,'El Limo',52),(1233,'El Roblal ',52),(1234,'El Tambo',52),(1235,'Filo de Medio',52),(1236,'La Cienega',52),(1237,'La Planta',52),(1238,'La Planta',52),(1239,'La Sierra',52),(1240,'Pinguro',52),(1241,'Sierrita',52),(1242,'Tinajitas',52),(1243,'Toyo',52),(1244,'Juan XXIII',53),(1245,'Girardota La Nueva',53),(1246,'Centro',53),(1247,'La Ferrer&iacute;a',53),(1248,'El Llano',53),(1249,'Monte Carlo',53),(1250,'Aureli Mejia',53),(1251,'San Jos&eacute;',53),(1252,'La Ceiba',53),(1253,'El Naranjal',53),(1254,'El Salado',53),(1255,'Nuevo Horizonte',53),(1256,'Guayacanes',53),(1257,'Santana',53),(1258,'Angosturita',54),(1259,'Balsas',54),(1260,'Caldera',54),(1261,'Ca&ntilde;averal',54),(1262,'Chilimaco',54),(1263,'Claritas',54),(1264,'El Arbolito',54),(1265,'El Brasil',54),(1266,'El Arbolito',54),(1267,'El Brasil',54),(1268,'El Cerro',54),(1269,'El Encanto',54),(1270,'El Guayabo',54),(1271,'El Indio',54),(1272,'El Oso',54),(1273,'El Salto',54),(1274,'El Tabl&oacute;n',54),(1275,'Garz&oacute;n',54),(1276,'Juntas',54),(1277,'La Acequia',54),(1278,'L a Arenera',54),(1279,'La Bonita',54),(1280,'La Clara',54),(1281,'La Estrella',54),(1282,'La Hondura',54),(1283,'La primavera',54),(1284,'La Regi&oacute;n',54),(1285,'Puente Porce',54),(1286,'Quebradona',54),(1287,'San Mat&iacute;as',54),(1288,'Santa Elena',54),(1289,'Trapichera',54),(1290,'Vega Botero',54),(1291,'Bella Maria',55),(1292,'Buena Vista',55),(1293,'Calderas',55),(1294,'Campo Alegre',55),(1295,'Cristalina - Cebadero',55),(1296,'Cristalina - Cruces',55),(1297,'El Chuscal',55),(1298,'El Concillo',55),(1299,'El Eden',55),(1300,'El Jardin',55),(1301,'El Libertador',55),(1302,'El Morro',55),(1303,'El Oso',55),(1304,'El Roblal',55),(1305,'El Tablazo',55),(1306,'El Tabor',55),(1307,'El Vergel ',55),(1308,'Gallea',55),(1309,'La Aguada',55),(1310,'La Arenosa',55),(1311,'La Aurora',55),(1312,'La Cascada',55),(1313,'La Eestrella',55),(1314,'La Florida ',55),(1315,'La Gaviota',55),(1316,'La Honda',55),(1317,'La Linda',55),(1318,'La Maria',55),(1319,'La Maria - El Progreso',55),(1320,'La Merced',55),(1321,'La Milagrosa',55),(1322,'La Primavera',55),(1323,'La Quiebra',55),(1324,'La Selva',55),(1325,'Las Faldas',55),(1326,'Las Palmas',55),(1327,'Las Vegas',55),(1328,'Los Medios',55),(1329,'Los Planes',55),(1330,'Malpaso',55),(1331,'Minitas',55),(1332,'Quebradona Abajo',55),(1333,'Quebradona Arriba',55),(1334,'Reyes',55),(1335,'San Esteban',55),(1336,'San Francisco',55),(1337,'San Matias',55),(1338,'San Miguel',55),(1339,'Santa Ana',55),(1340,'Tafetanes',55),(1341,'Vahitos',55),(1342,'Alto de San Juan',56),(1343,'Bramadora',56),(1344,'El Mango',56),(1345,'El Morro',56),(1346,'Guadalupe IV',56),(1347,'Guadal',56),(1348,'Guanteros',56),(1349,'Malabrigo',56),(1350,'Montania',56),(1351,'Morron',56),(1352,'Patio Bonito',56),(1353,'San Basilio Abajo',56),(1354,'San Basilio Arriba',56),(1355,'San Juan',56),(1356,'San Juli&aacute;n',56),(1357,'San Pablo Caney',56),(1358,'San Vicente El Kiosko',56),(1359,'San Vicente La Susana',56),(1360,'San Vicente Los Sauces',56),(1361,'Alto de la virgen',57),(1362,'Barro Blanco',57),(1363,'Brizuela',57),(1364,'Canoas',57),(1365,'Chaparral',57),(1366,'Colorado',57),(1367,'El Molino',57),(1368,'El Palmar',57),(1369,'El Salado',57),(1370,'Garrido',57),(1371,'Guamito',57),(1372,'Guapante',57),(1373,'Hojas Anchas',57),(1374,'Juan XXIII',57),(1375,'La Charanga',57),(1376,'La Clara',57),(1377,'La Enea',57),(1378,'La Honda',57),(1379,'La Hondita',57),(1380,'La Mejia',57),(1381,'La Mosca',57),(1382,'La Mosquita',57),(1383,'La Pastorcita',57),(1384,'Montanez',57),(1385,'Piedras Blancas',57),(1386,'Romeral',57),(1387,'San Ignacio',57),(1388,'San Isidro',57),(1389,'San Jose',57),(1390,'Toldas',57),(1391,'Yolombal',57),(1392,'Bonilla',58),(1393,'El Roble',58),(1394,'El Rosario',58),(1395,'Embalse Pe&ntilde;ol - Guatape',58),(1396,'La Pena',58),(1397,'La Piedra',58),(1398,'Los Naranjos',58),(1399,'Quebrada Arriba',58),(1400,'Santa Rita',58),(1401,'Alto del Corral ',59),(1402,'Chuscal',59),(1403,'Crucero',59),(1404,'EL Chocho',59),(1405,'El Hatillo',59),(1406,'Guamal',59),(1407,'Joly - Tablazo',59),(1408,'La Chorrera',59),(1409,'La Hondura',59),(1410,'La Pava',59),(1411,'La Pradera',59),(1412,'Llano de San Jose',59),(1413,'Llanos de San Jose',59),(1414,'Los Botes',59),(1415,'Monteadentro',59),(1416,'Palo Blanco',59),(1417,'Pueblito',59),(1418,'Pueblo Viejo',59);
/*!40000 ALTER TABLE `tbl_sector_barrio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_situacion_laboral`
--

DROP TABLE IF EXISTS `tbl_situacion_laboral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_situacion_laboral` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_situacion_laboral`
--

LOCK TABLES `tbl_situacion_laboral` WRITE;
/*!40000 ALTER TABLE `tbl_situacion_laboral` DISABLE KEYS */;
INSERT INTO `tbl_situacion_laboral` (`codigo`, `nombre`) VALUES (1,'Empleado'),(2,'Independiente'),(3,'Otro');
/*!40000 ALTER TABLE `tbl_situacion_laboral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_bien`
--

DROP TABLE IF EXISTS `tbl_tipo_bien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_bien` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_bien`
--

LOCK TABLES `tbl_tipo_bien` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_bien` DISABLE KEYS */;
INSERT INTO `tbl_tipo_bien` (`codigo`, `nombre`) VALUES (1,'Propiedad'),(2,'Vehiculo');
/*!40000 ALTER TABLE `tbl_tipo_bien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_documento`
--

DROP TABLE IF EXISTS `tbl_tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_documento` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_documento`
--

LOCK TABLES `tbl_tipo_documento` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_documento` DISABLE KEYS */;
INSERT INTO `tbl_tipo_documento` (`codigo`, `nombre`) VALUES (1,'C&eacute;dula de Ciudadan&iacute;a'),(2,'C&eacute;dula de Extranjer&iacute;a'),(3,'Otro');
/*!40000 ALTER TABLE `tbl_tipo_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_operacion`
--

DROP TABLE IF EXISTS `tbl_tipo_operacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_operacion` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_operacion`
--

LOCK TABLES `tbl_tipo_operacion` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_operacion` DISABLE KEYS */;
INSERT INTO `tbl_tipo_operacion` (`codigo`, `nombre`) VALUES (1,'Venta '),(2,'Arriendo '),(3,'Venta y Arriendo ');
/*!40000 ALTER TABLE `tbl_tipo_operacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_operacion_internacional`
--

DROP TABLE IF EXISTS `tbl_tipo_operacion_internacional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_operacion_internacional` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_operacion_internacional`
--

LOCK TABLES `tbl_tipo_operacion_internacional` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_operacion_internacional` DISABLE KEYS */;
INSERT INTO `tbl_tipo_operacion_internacional` (`codigo`, `nombre`) VALUES (1,'Importacion'),(2,'Exportacion'),(3,'Inversiones '),(4,'Transferencias '),(5,'Pagos de servicios'),(6,'Prestamos en moneda extranjera');
/*!40000 ALTER TABLE `tbl_tipo_operacion_internacional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_producto`
--

DROP TABLE IF EXISTS `tbl_tipo_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_producto` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_producto`
--

LOCK TABLES `tbl_tipo_producto` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_producto` DISABLE KEYS */;
INSERT INTO `tbl_tipo_producto` (`codigo`, `nombre`) VALUES (1,'Medios Informaticos');
/*!40000 ALTER TABLE `tbl_tipo_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo_propiedad`
--

DROP TABLE IF EXISTS `tbl_tipo_propiedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo_propiedad` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo_propiedad`
--

LOCK TABLES `tbl_tipo_propiedad` WRITE;
/*!40000 ALTER TABLE `tbl_tipo_propiedad` DISABLE KEYS */;
INSERT INTO `tbl_tipo_propiedad` (`codigo`, `nombre`) VALUES (1,'Casa'),(2,'Apartamento'),(3,'Lote'),(4,'Finca'),(5,'Casas campestres'),(6,'Bodegas'),(7,'Locales'),(8,'Oficinas'),(9,'Agroindustriales'),(10,'Aparta estudio ');
/*!40000 ALTER TABLE `tbl_tipo_propiedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_usuario`
--

DROP TABLE IF EXISTS `tbl_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_usuario` (
  `documento` int(15) NOT NULL,
  `imagen_perfil` varchar(15) NOT NULL DEFAULT 'default.png',
  `tipo_documento` int(11) DEFAULT NULL,
  `lugar_expedicion` int(11) DEFAULT NULL,
  `fecha_expedicion` date DEFAULT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `rol` int(11) NOT NULL,
  `ciudad` int(11) NOT NULL,
  `tel_movil` varchar(20) DEFAULT NULL,
  `tel_fijo` varchar(20) DEFAULT NULL,
  `tel_alternativo` varchar(20) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `direccion_correspondencia` varchar(250) DEFAULT NULL,
  `clave` varchar(60) NOT NULL,
  `puntuacion` int(11) DEFAULT NULL,
  `situacion_laboral` int(11) DEFAULT NULL,
  `cargo` varchar(255) DEFAULT NULL,
  `estado_civil` int(1) DEFAULT '4',
  `empresa_trabajo` int(11) DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  `numero_personas_acargo` int(2) NOT NULL,
  `profesion` int(11) DEFAULT NULL,
  `codigo_activacion` varchar(45) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `genero` int(1) DEFAULT NULL,
  PRIMARY KEY (`documento`),
  KEY `ciudad_idx` (`ciudad`),
  KEY `rol_idx` (`rol`),
  KEY `puntuacion_idx` (`puntuacion`),
  KEY `tipo_documento_usuario_idx` (`tipo_documento`),
  KEY `situacion_laboral_idx` (`situacion_laboral`),
  KEY `empresa_trabajo_idx` (`empresa_trabajo`),
  KEY `profesion_usuario_idx` (`profesion`),
  KEY `lugar_expedicion_usuario_idx` (`lugar_expedicion`),
  KEY `estado_civil_idx` (`estado_civil`) USING BTREE,
  KEY `genero_idx` (`genero`) USING BTREE,
  CONSTRAINT `ciudad` FOREIGN KEY (`ciudad`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `empresa_trabajo` FOREIGN KEY (`empresa_trabajo`) REFERENCES `tbl_empresa_trabajo` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lugar_expedicion_usuario` FOREIGN KEY (`lugar_expedicion`) REFERENCES `tbl_ciudad` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `profesion_usuario` FOREIGN KEY (`profesion`) REFERENCES `tbl_profesion` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `puntuacion` FOREIGN KEY (`puntuacion`) REFERENCES `tbl_puntuacion` (`codigo`),
  CONSTRAINT `rol` FOREIGN KEY (`rol`) REFERENCES `tbl_rol` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `situacion_laboral` FOREIGN KEY (`situacion_laboral`) REFERENCES `tbl_situacion_laboral` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_usuario_ibfk_1` FOREIGN KEY (`estado_civil`) REFERENCES `tbl_estado_civil` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_usuario_ibfk_2` FOREIGN KEY (`genero`) REFERENCES `tbl_genero` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tipo_documento_usuario` FOREIGN KEY (`tipo_documento`) REFERENCES `tbl_tipo_documento` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_usuario`
--

LOCK TABLES `tbl_usuario` WRITE;
/*!40000 ALTER TABLE `tbl_usuario` DISABLE KEYS */;
INSERT INTO `tbl_usuario` (`documento`, `imagen_perfil`, `tipo_documento`, `lugar_expedicion`, `fecha_expedicion`, `nombres`, `apellidos`, `email`, `fecha_nacimiento`, `rol`, `ciudad`, `tel_movil`, `tel_fijo`, `tel_alternativo`, `direccion`, `direccion_correspondencia`, `clave`, `puntuacion`, `situacion_laboral`, `cargo`, `estado_civil`, `empresa_trabajo`, `fecha_registro`, `numero_personas_acargo`, `profesion`, `codigo_activacion`, `estado`, `genero`) VALUES (1038414938,'default.png',1,71,'2013-07-01','Sebastian','Garc&iacute;a','sgarcia839@misena.edu.co','1995-07-15',2,71,'','','','cra30b#23-61',NULL,'$2y$10$FFav1tcENxFCaWGXdlv7K.HFXxoFZej3b2krv5ngZZqMTeAcvbfji',NULL,NULL,NULL,4,NULL,NULL,0,NULL,'R6q1lRRDSmYapBcjd1Gf4BFkqrxwT2qHhjRt4YAbdAjzG',1,1),(1094958193,'default.png',1,15,'2014-07-14','Jose Wilson','Marin Giraldo','jwmg10@hotmail.com','1996-08-31',2,15,'','','','JUAN XIII',NULL,'$2y$10$heJpmWjZ/QR6ymEHuFKmCOt4/sGaVSMz9Q/x3zQBBdy3tomIex1QW',NULL,NULL,NULL,4,NULL,NULL,0,NULL,'FJ0ijh86qg773ZRxWFfs8p8hqvnvkojJiuS1iokc9lrp_',1,1),(2147483647,'default.png',1,71,'2007-09-07','Edison','Osorio','edisonosorioj@gmail.com','1989-09-07',2,71,'3192967986','3192967986','5485108','Cra 31 No. 25 33 apt 403',NULL,'$2y$10$aYhaDmiZNLrMHklB8e4SFO4VE/014cmVCKDXyt8Hnjako4lwCND16',NULL,NULL,NULL,4,NULL,NULL,0,NULL,'Fg1i4XA6lVBkLZoHSZQ26LDTO54SzmLKw2e9u5pMHIH3b',1,1);
/*!40000 ALTER TABLE `tbl_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'brokersf_co'
--

--
-- Dumping routines for database 'brokersf_co'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-30 10:18:17
